import discord
from discord.ext import commands
import lavalink
from discord.ui import LayoutView, TextDisplay, Container

class MusicView(LayoutView):
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
    
    def finalize(self):
        self.add_item(self.container)

class Filters(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def create_view(self, content: str):
        view = MusicView()
        view.container.add_item(TextDisplay(content))
        view.finalize()
        return view

    async def get_player(self, ctx):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_connected:
            await ctx.send(view=self.create_view("I am not playing any music."))
            return None
        if not ctx.author.voice or (player.is_connected and ctx.author.voice.channel.id != int(player.channel_id)):
            await ctx.send(view=self.create_view("You need to be in my voice channel."))
            return None
        return player

    @commands.command(name="bassboost", aliases=["bb"])
    async def bassboost(self, ctx, level: str = "medium"):
        """bassboost <low/medium/high/extreme/off>"""
        player = await self.get_player(ctx)
        if not player: return

        levels = {
            "off": [0.0] * 15,
            "low": [0.10, 0.08, 0.05, 0.03] + [0.0] * 11,
            "medium": [0.20, 0.15, 0.10, 0.05] + [0.0] * 11,
            "high": [0.35, 0.25, 0.15, 0.10] + [0.0] * 11,
            "extreme": [0.50, 0.40, 0.30, 0.20, 0.15] + [0.0] * 10
        }

        if level.lower() not in levels:
            return await ctx.send(view=self.create_view("Levels: low, medium, high, extreme, off"))

        # FIXED: Pass list of tuples directly or use .update()
        bands = [(i, gain) for i, gain in enumerate(levels[level.lower()])]
        
        # Create filter object and update bands
        eq = lavalink.Equalizer()
        eq.update(bands=bands)
        await player.set_filter(eq)
        
        player.store('bassboost', level.lower() != "off")
        await ctx.send(view=self.create_view(f"✅ Bassboost set to: **{level.upper()}**"))

    @commands.command(name="enhance", aliases=["hq"])
    async def enhance(self, ctx, level: str = "medium"):
        """enhance <low/medium/high/off>"""
        player = await self.get_player(ctx)
        if not player: return

        levels = {
            "off": {"vol": 100, "bands": [0.0] * 15},
            "low": {"vol": 105, "bands": [0.1, 0.05, 0.0, 0.0, 0.0, -0.02, -0.02, 0.0, 0.0, 0.05, 0.1, 0.1, 0.05, 0.0, 0.0]},
            "medium": {"vol": 110, "bands": [0.15, 0.1, 0.05, 0.0, 0.0, -0.05, -0.05, 0.0, 0.05, 0.1, 0.15, 0.2, 0.1, 0.05, 0.0]},
            "high": {"vol": 120, "bands": [0.2, 0.15, 0.1, 0.05, 0.0, -0.05, -0.05, 0.0, 0.08, 0.15, 0.2, 0.25, 0.2, 0.1, 0.05]}
        }

        if level.lower() not in levels:
            return await ctx.send(view=self.create_view("Levels: low, medium, high, off"))

        config = levels[level.lower()]
        bands = [(i, gain) for i, gain in enumerate(config["bands"])]
        
        # FIXED: Using .update() pattern for maximum compatibility
        eq = lavalink.Equalizer()
        eq.update(bands=bands)
        
        await player.set_filter(eq)
        await player.set_volume(config["vol"])
        
        player.store('enhance', level.lower() != "off")
        await ctx.send(view=self.create_view(f"✨ Enhancement set to: **{level.upper()}**"))

    @commands.command(name="nightcore")
    async def nightcore(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('nightcore'):
            await player.remove_filter('timescale')
            player.store('nightcore', False)
            msg = "Nightcore disabled."
        else:
            ts = lavalink.Timescale()
            ts.update(speed=1.2, pitch=1.2)
            await player.set_filter(ts)
            player.store('nightcore', True)
            player.store('vaporwave', False)
            msg = "Nightcore enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="vaporwave")
    async def vaporwave(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('vaporwave'):
            await player.remove_filter('timescale')
            player.store('vaporwave', False)
            msg = "Vaporwave disabled."
        else:
            ts = lavalink.Timescale()
            ts.update(speed=0.8, pitch=0.8)
            await player.set_filter(ts)
            player.store('vaporwave', True)
            player.store('nightcore', False)
            msg = "Vaporwave enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="8d")
    async def rotation(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('8d'):
            await player.remove_filter('rotation')
            player.store('8d', False)
            msg = "8D Rotation disabled."
        else:
            rot = lavalink.Rotation()
            rot.update(rotation_hz=0.2)
            await player.set_filter(rot)
            player.store('8d', True)
            msg = "8D Rotation enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="karaoke")
    async def karaoke(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('karaoke'):
            await player.remove_filter('karaoke')
            player.store('karaoke', False)
            msg = "Karaoke filter disabled."
        else:
            await player.set_filter(lavalink.Karaoke())
            player.store('karaoke', True)
            msg = "Karaoke filter enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="tremolo")
    async def tremolo(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('tremolo'):
            await player.remove_filter('tremolo')
            player.store('tremolo', False)
            msg = "Tremolo disabled."
        else:
            t = lavalink.Tremolo()
            t.update(frequency=4.0, depth=0.5)
            await player.set_filter(t)
            player.store('tremolo', True)
            msg = "Tremolo enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="vibrato")
    async def vibrato(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('vibrato'):
            await player.remove_filter('vibrato')
            player.store('vibrato', False)
            msg = "Vibrato disabled."
        else:
            v = lavalink.Vibrato()
            v.update(frequency=5.0, depth=0.5)
            await player.set_filter(v)
            player.store('vibrato', True)
            msg = "Vibrato enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="lowpass")
    async def lowpass(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        if player.fetch('lowpass'):
            await player.remove_filter('lowpass')
            player.store('lowpass', False)
            msg = "Lowpass disabled."
        else:
            lp = lavalink.LowPass()
            lp.update(smoothing=20.0)
            await player.set_filter(lp)
            player.store('lowpass', True)
            msg = "Lowpass enabled."
        await ctx.send(view=self.create_view(msg))

    @commands.command(name="resetfilters", aliases=["rf"])
    async def reset_filters(self, ctx):
        player = await self.get_player(ctx)
        if not player: return

        await player.clear_filters()
        await player.set_volume(100)
        for f in ['nightcore', 'vaporwave', '8d', 'karaoke', 'tremolo', 'vibrato', 'lowpass', 'bassboost', 'enhance']:
            player.store(f, False)
        await ctx.send(view=self.create_view("All filters have been cleared."))

async def setup(bot: commands.Bot):
    await bot.add_cog(Filters(bot))