import discord
from discord.ext import commands
import aiosqlite
import re
from discord.ui import LayoutView, TextDisplay, Container


class MusicView(LayoutView):
    def __init__(self, content: str):
        super().__init__(timeout=None)
        container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
        container.add_item(TextDisplay(content))
        self.add_item(container)


class Playlist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = "database.db"


    async def cog_load(self):
        async with aiosqlite.connect(self.db) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    name TEXT,
                    UNIQUE(user_id, name)
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS playlist_tracks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    playlist_id INTEGER,
                    title TEXT,
                    author TEXT,
                    duration INTEGER
                )
            """)
            await db.commit()


    async def get_playlist_id(self, user_id: int, name: str):
        async with aiosqlite.connect(self.db) as db:
            async with db.execute(
                "SELECT id FROM playlists WHERE user_id = ? AND name = ?",
                (user_id, name)
            ) as cur:
                row = await cur.fetchone()
                return row[0] if row else None

    def view(self, text: str):
        return MusicView(text)


    @commands.group(name="playlist", aliases=["pl"], invoke_without_command=True)
    async def playlist(self, ctx):
        pass

    @playlist.command(name="list")
    async def list_playlists(self, ctx):
        async with aiosqlite.connect(self.db) as db:
            async with db.execute("""
                SELECT p.name, COUNT(t.id)
                FROM playlists p
                LEFT JOIN playlist_tracks t ON p.id = t.playlist_id
                WHERE p.user_id = ?
                GROUP BY p.id
            """, (ctx.author.id,)) as cur:
                rows = await cur.fetchall()

        if not rows:
            return await ctx.send(view=self.view("You have no playlists."))

        msg = "**Your Playlists**\n\n"
        for i, (name, count) in enumerate(rows, 1):
            msg += f"{i}. **{name}** — {count} tracks\n"

        await ctx.send(view=self.view(msg))


    @playlist.command(name="import")
    async def import_playlist(self, ctx, service: str, link: str):
        if "spotify" not in service.lower():
            return await ctx.send(view=self.view("Only Spotify is supported."))

        node = self.bot.lavalink.node_manager.nodes[0]
        result = await node.get_tracks(link.strip("<>"))

        if not result or not result.tracks:
            return await ctx.send(view=self.view("Could not load Spotify playlist."))

        async with aiosqlite.connect(self.db) as db:
            async with db.execute(
                "SELECT name FROM playlists WHERE user_id = ? AND name LIKE 'Spotify %'",
                (ctx.author.id,)
            ) as cur:
                existing = [int(m.group(1)) for (n,) in await cur.fetchall()
                            if (m := re.search(r"Spotify (\d+)", n))]

            name = f"Spotify {max(existing)+1 if existing else 1}"
            await db.execute(
                "INSERT INTO playlists (user_id, name) VALUES (?, ?)",
                (ctx.author.id, name)
            )
            await db.commit()

            async with db.execute(
                "SELECT id FROM playlists WHERE user_id = ? AND name = ?",
                (ctx.author.id, name)
            ) as cur:
                pid = (await cur.fetchone())[0]

            for t in result.tracks:
                await db.execute("""
                    INSERT INTO playlist_tracks (playlist_id, title, author, duration)
                    VALUES (?, ?, ?, ?)
                """, (pid, t.title, t.author, t.duration))

            await db.commit()

        await ctx.send(view=self.view(
            f"**Spotify Import Successful**\n"
            f"Playlist: `{name}`\n"
            f"Tracks: `{len(result.tracks)}`"
        ))


    @playlist.command(name="play")
    async def play_playlist(self, ctx, *, name: str):
        pid = await self.get_playlist_id(ctx.author.id, name)
        if not pid:
            return await ctx.send(view=self.view("Playlist not found."))

        music = self.bot.get_cog("Music")
        if not music or not await music.create_player(ctx):
            return

        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        node = self.bot.lavalink.node_manager.nodes[0]

        async with aiosqlite.connect(self.db) as db:
            async with db.execute("""
                SELECT title, author, duration
                FROM playlist_tracks
                WHERE playlist_id = ?
            """, (pid,)) as cur:
                tracks = await cur.fetchall()

        if not tracks:
            return await ctx.send(view=self.view("Playlist is empty."))

        added = 0

        for title, author, duration in tracks:
            author = re.sub(r"(,|&|feat\.?).*", "", author, flags=re.I)
            query = f"{title} {author}"

            res = await node.get_tracks(f"ytsearch:{query}")
            if not res or not res.tracks:
                continue

            yt = res.tracks[0]

            if abs(yt.duration - duration) > 5000:
                continue

            player.add(requester=ctx.author.id, track=yt)
            added += 1

            if not player.is_playing:
                await player.play()

        await ctx.send(view=self.view(
            f"Queued `{added}` tracks from **{name}**"
        ))


    @playlist.command(name="add")
    async def add(self, ctx, mode: str, *, name: str):
        pid = await self.get_playlist_id(ctx.author.id, name)
        if not pid:
            return await ctx.send(view=self.view("Playlist not found."))

        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player:
            return await ctx.send(view=self.view("Nothing playing."))

        tracks = []

        if mode.lower() == "track" and player.current:
            tracks.append(player.current)
        elif mode.lower() in ("queue", "q"):
            tracks.extend(player.queue)

        if not tracks:
            return await ctx.send(view=self.view("No tracks to add."))

        async with aiosqlite.connect(self.db) as db:
            for t in tracks:
                await db.execute("""
                    INSERT INTO playlist_tracks (playlist_id, title, author, duration)
                    VALUES (?, ?, ?, ?)
                """, (pid, t.title, t.author, t.duration))
            await db.commit()

        await ctx.send(view=self.view(
            f"Added `{len(tracks)}` tracks to **{name}**"
        ))


    @playlist.command(name="delete")
    async def delete(self, ctx, *, name: str):
        pid = await self.get_playlist_id(ctx.author.id, name)
        if not pid:
            return await ctx.send(view=self.view("Playlist not found."))

        async with aiosqlite.connect(self.db) as db:
            await db.execute("DELETE FROM playlists WHERE id = ?", (pid,))
            await db.commit()

        await ctx.send(view=self.view(f"Deleted playlist **{name}**"))


async def setup(bot: commands.Bot):
    await bot.add_cog(Playlist(bot))