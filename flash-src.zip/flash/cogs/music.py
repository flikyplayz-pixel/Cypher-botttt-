import discord 
from discord import AllowedMentions, PartialEmoji
from discord.ext import commands
import re
import random
import lavalink
from datetime import timedelta
from discord import ui
from discord.ui import (
    LayoutView, 
    TextDisplay, 
    Container, 
    Section, 
    Separator, 
    Thumbnail, 
    ActionRow, 
    Button,
    Select  # Added Select
)
from lavalink.events import (
    TrackStartEvent,
    TrackEndEvent,
    QueueEndEvent,
    TrackExceptionEvent,
    TrackStuckEvent
)
from lavalink.errors import ClientError
import asyncio

URL_REGEX = re.compile(r'https?://(?:www\.)?.+')

class MusicView(LayoutView):
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
    
    def finalize(self):
        self.add_item(self.container)

# --- Dropdown for Removing Songs ---
class QueueRemoveSelect(discord.ui.Select):
    def __init__(self, player):
        self.player = player
        options = []
        
        # Discord Select menus are limited to 25 options
        for i, track in enumerate(player.queue[:25]):
            # Truncate title if too long for SelectOption label
            label = (track.title[:90] + '..') if len(track.title) > 92 else track.title
            options.append(discord.SelectOption(
                label=f"{i+1}. {label}",
                value=str(i),
                description=f"by {track.author[:50]}"
            ))

        super().__init__(
            placeholder="Select a song to remove from queue...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.voice or interaction.user.voice.channel.id != int(self.player.channel_id):
            return await interaction.response.send_message("You must be in the voice channel to edit the queue.", ephemeral=True)

        index = int(self.values[0])
        if index < len(self.player.queue):
            removed_track = self.player.queue.pop(index)
            await interaction.response.send_message(f"✅ Removed **{removed_track.title}** from the queue.", ephemeral=True)
            
            # Optionally update the message to reflect the new queue
            # (Requires re-fetching the queue list logic)
        else:
            await interaction.response.send_message("Track no longer exists in queue.", ephemeral=True)

class LavalinkVoiceClient(discord.VoiceProtocol):
    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        self.client = client
        self.channel = channel
        self.guild_id = channel.guild.id
        self._destroyed = False
        self.lavalink = self.client.lavalink

    async def on_voice_server_update(self, data):
        lavalink_data = {
            't': 'VOICE_SERVER_UPDATE',
            'd': data
        }
        await self.lavalink.voice_update_handler(lavalink_data)

    async def on_voice_state_update(self, data):
        channel_id = data['channel_id']

        if not channel_id:
            await self._destroy()
            return

        self.channel = self.client.get_channel(int(channel_id))

        lavalink_data = {
            't': 'VOICE_STATE_UPDATE',
            'd': data
        }

        await self.lavalink.voice_update_handler(lavalink_data)

    async def connect(self, *, timeout: float, reconnect: bool, self_deaf: bool = False, self_mute: bool = False) -> None:
        self.lavalink.player_manager.create(guild_id=self.channel.guild.id)
        await self.channel.guild.change_voice_state(channel=self.channel, self_mute=self_mute, self_deaf=self_deaf)

    async def disconnect(self, *, force: bool = False) -> None:
        player = self.lavalink.player_manager.get(self.channel.guild.id)

        if not force and not player.is_connected:
            return

        await self.channel.guild.change_voice_state(channel=None)

        player.channel_id = None
        await self._destroy()

    async def _destroy(self):
        self.cleanup()

        if self._destroyed:
            return

        self._destroyed = True

        try:
            await self.lavalink.player_manager.destroy(self.guild_id)
        except ClientError:
            pass

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.lavalink = bot.lavalink
        self.user_sources = {}
        self.color = discord.Color.red()
        self._play_locks = {}

    async def cog_load(self):
        self.bot.loop.create_task(self.connect_hooks())

    async def connect_hooks(self):
        await self.bot.wait_until_ready()
        for _ in range(10): 
            lava = getattr(self.bot, 'lavalink', None)
            if lava:
                lava.add_event_hooks(self)
                break
            await asyncio.sleep(1)

    async def create_player(self, ctx: commands.Context):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()

        player = ctx.bot.lavalink.player_manager.create(ctx.guild.id)
        should_connect = ctx.command.name in ('play',)
        voice_client = ctx.voice_client

        if not ctx.author.voice or not ctx.author.voice.channel:
            if voice_client is not None:
                view = MusicView()
                view.container.add_item(TextDisplay("You need to join my voice channel first."))
                view.finalize()
                await ctx.send(view=view)
                return False
            view = MusicView()
            view.container.add_item(TextDisplay("Join a voice channel first."))
            view.finalize()
            await ctx.send(view=view)
            return False

        voice_channel = ctx.author.voice.channel

        if voice_client is None:
            if not should_connect:
                view = MusicView()
                view.container.add_item(TextDisplay("I'm not playing music."))
                view.finalize()
                await ctx.send(view=view)
                return False

            permissions = voice_channel.permissions_for(ctx.me)

            if not permissions.connect or not permissions.speak:
                view = MusicView()
                view.container.add_item(TextDisplay("I need the `CONNECT` and `SPEAK` permissions."))
                view.finalize()
                await ctx.send(view=view)
                return False

            if voice_channel.user_limit > 0:
                if len(voice_channel.members) >= voice_channel.user_limit and not ctx.me.guild_permissions.move_members:
                    view = MusicView()
                    view.container.add_item(TextDisplay("Your voice channel is full!"))
                    view.finalize()
                    await ctx.send(view=view)
                    return False

            player.store('channel', ctx.channel.id)
            await ctx.author.voice.channel.connect(cls=LavalinkVoiceClient, self_deaf=True)
        elif voice_client.channel.id != voice_channel.id:
            view = MusicView()
            view.container.add_item(TextDisplay("You need to be in my voice channel."))
            view.finalize()
            await ctx.send(view=view)
            return False
        
        if not hasattr(player, 'home'):
            player.home = ctx.channel 

        return True

    @lavalink.listener(TrackStartEvent)
    async def on_track_start(self, event: TrackStartEvent):
        player = event.player
        track = event.track

        if player.fetch('last_id') == track.identifier:
            return

        player.store('last_id', track.identifier)
        player.store('last_track', track)
    
        guild = self.bot.get_guild(player.guild_id)
        if not guild or not hasattr(player, 'home'): 
            return

        old_msg_id = player.fetch('msg_id')
        if old_msg_id:
            try:
                old_msg = await player.home.fetch_message(old_msg_id)
                await old_msg.delete()
            except: 
                pass

        artwork = getattr(track, "artwork_url", None) or "https://via.placeholder.com/300x300"
        title = (track.title[:35] + '..') if len(track.title) > 38 else track.title
        requester = guild.get_member(track.requester) or await self.bot.fetch_user(track.requester)

        view = MusicView()
        content = (
            f"### Now Playing\n"
            f"**[{title}]({track.uri})**\n"
            f"-# {track.author[:20]} | {lavalink.utils.format_time(track.duration)}\n\n"
            f"-# added by `{requester.name}` • Vol: `{player.volume}`"
        )
        
        row = ActionRow()
        row.add_item(self.MusicBtn(player, "loop", emoji=PartialEmoji(name="loop", id=1466655514199855108)))
        row.add_item(self.MusicBtn(player, "pause", emoji=PartialEmoji(name="pause", id=1466655445954330634)))
        row.add_item(self.MusicBtn(player, "skip", emoji=PartialEmoji(name="skip_next", id=1466655479618076845)))
        row.add_item(self.MusicBtn(player, "stop", emoji=PartialEmoji(name="stop", id=1466770518781857846)))
        
        view.container.add_item(Section(content, accessory=Thumbnail(media=discord.UnfurledMediaItem(url=artwork))))
        view.container.add_item(Separator())
        view.container.add_item(row)
        view.finalize()
        
        msg = await player.home.send(view=view)
        player.store('msg_id', msg.id)
        
        if event.track.requester:
            await self.bot.db.execute("""
                INSERT INTO user_stats (user_id, songs_played) 
                VALUES (?, 1) 
                ON CONFLICT(user_id) 
                DO UPDATE SET songs_played = songs_played + 1
            """, event.track.requester)

    class MusicBtn(Button):
        def __init__(self, player, action, emoji=None):
            style = discord.ButtonStyle.secondary
            if action == "loop":
                style = discord.ButtonStyle.danger
            elif action == "stop":
                style = discord.ButtonStyle.danger
            
            super().__init__(
                style=style,
                emoji=emoji
            )
            self.player = player
            self.action = action
        
        async def callback(self, interaction: discord.Interaction):
            if not interaction.user.voice:
                await interaction.response.send_message("You are not in a voice channel.", ephemeral=True)
                return
            if not interaction.guild.voice_client or interaction.user.voice.channel != interaction.guild.voice_client.channel:
                await interaction.response.send_message("You are not in the same voice channel.", ephemeral=True)
                return

            if self.action == "loop":
                self.player.loop = 1 if self.player.loop == 0 else 0
                await interaction.response.send_message(f"Loop {'enabled' if self.player.loop else 'disabled'}", ephemeral=True)
            elif self.action == "pause":
                await self.player.set_pause(not self.player.paused)
                await interaction.response.send_message("Toggled Pause", ephemeral=True)
            elif self.action == "skip":
                if self.player.is_playing:
                    await self.player.skip()
                    await interaction.response.send_message("Skipped", ephemeral=True)
                else:
                    await interaction.response.send_message("No music is playing.", ephemeral=True)
            elif self.action == "stop":
                if self.player.is_playing:
                    await self.player.stop()
                    if interaction.guild.voice_client: 
                        await interaction.guild.voice_client.disconnect(force=True)
                    await interaction.response.send_message("Stopped", ephemeral=True)
                else:
                    await interaction.response.send_message("No music is playing.", ephemeral=True)

    @lavalink.listener(QueueEndEvent)
    async def on_queue_end(self, event: QueueEndEvent):
        player = event.player
        if player.fetch('autoplay'):
            try:
                last = player.fetch('last_track')
                if last:
                    last_title = getattr(last, "title", "Unknown")
                    last_author = getattr(last, "author", "")
                    last_id = getattr(last, "identifier", None)
                    search_query = f"ytsearch:{last_author} {last_title} related music"
                    results = await player.node.get_tracks(search_query)
                    tracks = results.get("tracks", []) if isinstance(results, dict) else getattr(results, "tracks", []) or []

                    if tracks:
                        candidates = [t for t in tracks if t.identifier != last_id]
                        next_track = random.choice(candidates[:5]) if candidates else tracks[0]
                        player.add(requester=self.bot.user.id, track=next_track)
                        await player.play()
                        return
            except Exception as e:
                print(f"Autoplay Error: {e}")

        if player.fetch('247'):
            return

        guild = self.bot.get_guild(int(player.guild_id))
        if guild and guild.voice_client:
            await guild.voice_client.disconnect(force=True)

    @commands.command(name="play", aliases=['p'])
    async def play(self, ctx: commands.Context, *, query: str):
        if self._play_locks.get(ctx.guild.id): 
            return
        self._play_locks[ctx.guild.id] = True

        try:
            if not ctx.author.voice:
                view = MusicView()
                view.container.add_item(TextDisplay("You must be in a voice channel to use this command."))
                view.finalize()
                await ctx.send(view=view)
                return
            
            if not await self.create_player(ctx):
                return
            
            player = self.bot.lavalink.player_manager.get(ctx.guild.id)
            user_source = self.user_sources.get(ctx.author.id, "spsearch")
            
            if query.startswith("https://open.spotify.com"):
                source = None
            elif query.startswith('yt '):
                source = "ytsearch"
                query = query.replace("yt", "")
            elif query.startswith('sp '):
                source = "spsearch"
                query = query.replace("sp", "")
            else:
                source = user_source
            
            query = query.strip("<>")
            search_query = query if source is None else f"{source}:{query}"
            
            if source is None and not URL_REGEX.match(query):
                search_query = f"ytsearch:{query}"
            
            results = await player.node.get_tracks(search_query)
            if isinstance(results, dict):
                load_type = results.get("loadType")
                tracks = results.get("tracks", [])
            else:
                load_type = getattr(results, "loadType", None) or getattr(results, "load_type", None)
                tracks = getattr(results, "tracks", []) or []

            if not results or not tracks:
                view = MusicView()
                view.container.add_item(TextDisplay("Nothing found!"))
                view.finalize()
                return await ctx.send(view=view)

            view = MusicView()
            if load_type == 'PLAYLIST_LOADED':
                for track in tracks:
                    player.add(requester=ctx.author.id, track=track)
                playlist_name = results.get('playlistInfo', {}).get('name') if isinstance(results, dict) else getattr(results, "playlistInfo", {}).get("name", "Unknown")
                view.container.add_item(TextDisplay(f"### Added to queue\nPlaylist: **{playlist_name}** ({len(tracks)} tracks)"))
                view.finalize()
            else:
                track = tracks[0]
                player.add(track=track, requester=ctx.author.id)
                short_t = (track.title[:30] + '..') if len(track.title) > 33 else track.title
                view.container.add_item(TextDisplay(f"Added track [{short_t}]({track.uri}) to queue by **<@{ctx.author.id}>**"))
                view.finalize()
            
            await ctx.send(view=view, delete_after=5, allowed_mentions=AllowedMentions.none())
            if not player.is_playing:
                await player.play()
        
        finally:
            await asyncio.sleep(1)
            self._play_locks[ctx.guild.id] = False

    @commands.command(name="queue", aliases=['q'])
    async def queue(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.current:
            view = MusicView()
            view.container.add_item(TextDisplay("There is nothing playing right now."))
            view.finalize()
            return await ctx.send(view=view)
            
        content = f"### Queue for {ctx.guild.name}\n"
        content += f"**Now Playing:** [{player.current.title}]({player.current.uri})\n\n"
        
        if player.queue:
            content += "**Upcoming Songs:**\n"
            for i, track in enumerate(player.queue[:10], 1):
                content += f"`{i}.` {track.title[:45]}.. | {lavalink.utils.format_time(track.duration)}\n"
            
            if len(player.queue) > 10:
                content += f"\n-# ... and {len(player.queue) - 10} more tracks"
        else:
            content += "*The queue is currently empty.*"
        
        view = MusicView()
        view.container.add_item(TextDisplay(content))
        
        # Add the dropdown if there are items in the queue
        if player.queue:
            view.container.add_item(Separator())
            # We use a standard ActionRow to hold the select menu
            row = ActionRow()
            row.add_item(QueueRemoveSelect(player))
            view.container.add_item(row)

        view.finalize()
        await ctx.send(view=view)

    # ... [Keep all other commands: 247, autoplay, pause, resume, stop, volume, skip, nowplaying, disconnect, repeat] ...

    @commands.command(name="247", aliases=['stay', '24/7'])
    @commands.has_permissions(manage_guild=True)
    async def twenty_four_seven(self, ctx: commands.Context):
        if not await self.create_player(ctx): return
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        is_247 = not player.fetch('247', False)
        player.store('247', is_247)
        view = MusicView()
        view.container.add_item(TextDisplay(f"24/7 mode has been **{'enabled' if is_247 else 'disabled'}**."))
        view.finalize()
        await ctx.send(view=view)

    @commands.command(name="autoplay", aliases=['ap'])
    async def autoplay(self, ctx: commands.Context):
        if not await self.create_player(ctx): return
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        is_ap = not player.fetch('autoplay', False)
        player.store('autoplay', is_ap)
        view = MusicView()
        view.container.add_item(TextDisplay(f"Autoplay has been **{'enabled' if is_ap else 'disabled'}**."))
        view.finalize()
        await ctx.send(view=view)

    @commands.command(name="pause")
    async def pause(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            view = MusicView()
            view.container.add_item(TextDisplay("I'm not playing anything."))
            view.finalize()
            return await ctx.send(view=view)
        await player.set_pause(True)
        view = MusicView()
        view.container.add_item(TextDisplay("Paused the player."))
        view.finalize()
        await ctx.send(view=view, delete_after=5)

    @commands.command(name="resume")
    async def resume(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.paused:
            view = MusicView()
            view.container.add_item(TextDisplay("I'm not paused."))
            view.finalize()
            return await ctx.send(view=view)
        await player.set_pause(False)
        view = MusicView()
        view.container.add_item(TextDisplay("Resumed the player."))
        view.finalize()
        await ctx.send(view=view, delete_after=5)

    @commands.command(name="stop")
    async def stop(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player: return
        player.queue.clear()
        await player.stop()
        if ctx.voice_client: await ctx.voice_client.disconnect(force=True)
        view = MusicView()
        view.container.add_item(TextDisplay("Stopped the player and disconnected."))
        view.finalize()
        await ctx.send(view=view, delete_after=5)

    @commands.command(name="volume", aliases=['vol'])
    async def volume(self, ctx: commands.Context, volume: int):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player: return
        if not 0 <= volume <= 200:
            view = MusicView()
            view.container.add_item(TextDisplay("Volume must be between 0 and 200."))
            view.finalize()
            return await ctx.send(view=view)
        await player.set_volume(volume)
        view = MusicView()
        view.container.add_item(TextDisplay(f"Set volume to {volume}%"))
        view.finalize()
        await ctx.send(view=view, delete_after=5)

    @commands.command(name="skip")
    async def skip(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing: return
        current_track = player.current
        await player.skip()
        view = MusicView()
        view.container.add_item(TextDisplay(f"Skipped: {current_track.title}"))
        view.finalize()
        await ctx.send(view=view, delete_after=5)

    @commands.command(name="nowplaying", aliases=['np'])
    async def nowplaying(self, ctx: commands.Context):
        guild = ctx.guild
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.current: return
        current_track = player.current
        artwork_url = getattr(current_track, "artwork_url", None) or "https://via.placeholder.com/300x300"
        current_time, total_duration = player.position, current_track.duration
        requester = guild.get_member(current_track.requester) or await self.bot.fetch_user(current_track.requester)
        duration_str, current_str = str(timedelta(milliseconds=total_duration))[2:7], str(timedelta(milliseconds=current_time))[2:7]
        progress = (current_time / total_duration) * 100
        progress_bar = "█" * int(progress / 5) + "░" * (15 - int(progress / 5))
        content = f"**[{current_track.title}]({current_track.uri})** - {current_track.author}\n\n-# added by `{requester.name}` • Vol: `{player.volume}`\n"
        view = MusicView()
        view.container.add_item(TextDisplay("## Now Playing"))
        view.container.add_item(Separator())
        view.container.add_item(Section(content, accessory=Thumbnail(media=discord.UnfurledMediaItem(url=artwork_url))))
        view.container.add_item(Separator())
        view.container.add_item(TextDisplay(f"{current_str} {progress_bar} {duration_str}"))
        view.finalize()
        await ctx.send(view=view)

    @commands.command(name="disconnect", aliases=['dc', 'leave'])
    async def disconnect(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not ctx.voice_client: return
        if player:
            player.queue.clear()
            await player.stop()
        await ctx.voice_client.disconnect(force=True)
        view = MusicView()
        view.container.add_item(TextDisplay("Disconnected from voice channel."))
        view.finalize()
        await ctx.send(view=view)

    @commands.command(name="repeat", aliases=["loop", "l"])
    async def repeat(self, ctx: commands.Context):
        player = self.bot.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing: return
        if player.loop == lavalink.DefaultPlayer.LOOP_SINGLE:
            player.loop = lavalink.DefaultPlayer.LOOP_NONE
            msg = "Loop has been disabled."
        else:
            player.loop = lavalink.DefaultPlayer.LOOP_SINGLE
            msg = "Loop has been enabled for current track."
        view = MusicView()
        view.container.add_item(TextDisplay(msg))
        view.finalize()
        await ctx.send(view=view)

async def setup(bot: commands.Bot):
    cog = Music(bot)
    await bot.add_cog(cog)
    if bot.lavalink: bot.lavalink.add_event_hooks(cog)