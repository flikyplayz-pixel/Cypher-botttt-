import discord
from discord.ext import commands
import lavalink
import aiohttp
import random
import re
from discord.ui import LayoutView, TextDisplay, Container

# Matching the UI components from your music.py
class MusicView(LayoutView):
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
    
    def finalize(self):
        self.add_item(self.container)

class Search(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Multiple API mirrors for redundancy
        self.radio_apis = [
            "https://de1.api.radio-browser.info",
            "https://nl1.api.radio-browser.info",
            "https://fr1.api.radio-browser.info",
            "https://at1.api.radio-browser.info",
        ]

    def create_view(self, content: str):
        """Helper to create the consistent Music UI."""
        view = MusicView()
        view.container.add_item(TextDisplay(content))
        view.finalize()
        return view

    async def fetch_radio_data(self, endpoint: str, params: dict = None):
        """Tries multiple API mirrors until one responds."""
        random.shuffle(self.radio_apis)
        async with aiohttp.ClientSession() as session:
            for base_url in self.radio_apis:
                try:
                    url = f"{base_url}/json/{endpoint}"
                    async with session.get(url, params=params, timeout=5) as resp:
                        if resp.status == 200:
                            return await resp.json()
                except:
                    continue
        return None

    async def ensure_player(self, ctx):
        """Logic to ensure player is created using Music cog's method."""
        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            return None
        if not await music_cog.create_player(ctx):
            return None
        return self.bot.lavalink.player_manager.get(ctx.guild.id)

    @commands.group(name="radio", invoke_without_command=True)
    async def radio(self, ctx, frequency: str):
        """radio [station number/frequency] - e.g., !radio 92.7"""
        # Ensure input is a number or frequency (e.g. 92.7, 108)
        if not re.match(r"^\d+(\.\d+)?$", frequency):
            return await ctx.send(view=self.create_view("Please provide a valid numeric frequency or station number."))

        player = await self.ensure_player(ctx)
        if not player: return

        # Search for stations matching the frequency number
        data = await self.fetch_radio_data("stations/byname/" + frequency, params={"limit": 5})

        if not data:
            return await ctx.send(view=self.create_view(f"No live station found on frequency: {frequency}"))

        # Find the best quality stream from results
        station_data = data[0]
        stream_url = station_data.get('url_resolved') or station_data.get('url')
        name = station_data.get('name')
        country = station_data.get('countrycode')

        results = await player.node.get_tracks(stream_url)
        if not results or not results.tracks:
            return await ctx.send(view=self.create_view(f"Station {name} is currently offline."))

        track = results.tracks[0]
        track.title = f"Radio {frequency}: {name}"
        
        player.add(requester=ctx.author.id, track=track)
        
        content = (
            f"**Tuned into Frequency: {frequency}**\n\n"
            f"**Station:** {name}\n"
            f"**Location:** {country}\n"
            f"**Status:** Real-time Broadcast"
        )
        await ctx.send(view=self.create_view(content))

        if not player.is_playing:
            await player.play()

    @radio.command(name="list")
    async def radio_list(self, ctx):
        """Shows a list of popular station frequencies."""
        # Fetch top clicked stations to show as a 'frequency list'
        data = await self.fetch_radio_data("stations/topclick", params={"limit": 20})
        
        if not data:
            return await ctx.send(view=self.create_view("Could not retrieve station list."))

        content = "**Available Radio Frequencies/Stations**\n\n"
        for entry in data:
            name = entry.get('name')
            # Extract numbers/frequencies from name if possible
            freq_match = re.search(r"\d+(\.\d+)?", name)
            freq_display = freq_match.group(0) if freq_match else "Live"
            content += f"Frequency: {freq_display} | {name[:25]}\n"

        content += "\nUse !radio [frequency] to tune in."
        await ctx.send(view=self.create_view(content))

    @commands.command(name="discover")
    async def discover(self, ctx, *, mood_genre: str):
        player = await self.ensure_player(ctx)
        if not player: return
        results = await player.node.get_tracks(f"ytsearch:{mood_genre} music recommendations")
        if not results or not results.tracks:
            return await ctx.send(view=self.create_view("No recommendations found."))
        for track in results.tracks[:10]:
            player.add(requester=ctx.author.id, track=track)
        await ctx.send(view=self.create_view(f"Discovered and queued 10 tracks for: {mood_genre}"))
        if not player.is_playing: await player.play()

    @commands.command(name="year")
    async def year(self, ctx, year: int, *, genre: str = ""):
        player = await self.ensure_player(ctx)
        if not player: return
        results = await player.node.get_tracks(f"ytsearch:best {genre} hits of {year}")
        if not results or not results.tracks:
            return await ctx.send(view=self.create_view(f"No music found for {year}."))
        for track in results.tracks[:10]:
            player.add(requester=ctx.author.id, track=track)
        await ctx.send(view=self.create_view(f"Queued top {year} hits."))
        if not player.is_playing: await player.play()

    @commands.command(name="chart")
    async def chart(self, ctx, country: str, year: str = ""):
        player = await self.ensure_player(ctx)
        if not player: return
        results = await player.node.get_tracks(f"ytsearch:top charts {country} {year}")
        if not results or not results.tracks:
            return await ctx.send(view=self.create_view("Charts not found."))
        for track in results.tracks[:15]:
            player.add(requester=ctx.author.id, track=track)
        await ctx.send(view=self.create_view(f"Queued {country} charts."))
        if not player.is_playing: await player.play()

    @commands.command(name="mix")
    async def mix(self, ctx, artist1: str, artist2: str):
        player = await self.ensure_player(ctx)
        if not player: return
        res1 = await player.node.get_tracks(f"ytsearch:{artist1} songs")
        res2 = await player.node.get_tracks(f"ytsearch:{artist2} songs")
        added = 0
        for t1, t2 in zip(res1.tracks[:5], res2.tracks[:5]):
            player.add(requester=ctx.author.id, track=t1)
            player.add(requester=ctx.author.id, track=t2)
            added += 2
        await ctx.send(view=self.create_view(f"Created mix for {artist1} and {artist2}. Queued {added} tracks."))
        if not player.is_playing: await player.play()

async def setup(bot: commands.Bot):
    await bot.add_cog(Search(bot))