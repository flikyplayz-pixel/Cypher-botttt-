import discord
from discord.ext import commands
from discord.ui import (
    LayoutView,
    TextDisplay,
    Thumbnail,
    Separator,
    Container,
    Section,
    Button,
    ActionRow,
    Modal,
    TextInput
)
from discord import ButtonStyle, AllowedMentions
from typing import Union, Optional, TYPE_CHECKING, List
import datetime
import time
import platform
import psutil
import aiohttp
import re

if TYPE_CHECKING:
    from main import Antinuke

# --- UI BASE CLASSES ---

class BaseInfoView(LayoutView):
    """The base UI template for all responses."""
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))

    def finalize(self):
        self.add_item(self.container)

class SimpleView(BaseInfoView):
    """Generic UI box for pings, alerts, and small messages."""
    def __init__(self, text: str):
        super().__init__()
        self.container.add_item(TextDisplay(text))
        self.finalize()

class ServerView(BaseInfoView):
    """UI box used specifically by the ignore/server management commands."""
    def __init__(self):
        super().__init__()

class BotInfoView(LayoutView):
    def __init__(self, bot):
        super().__init__(timeout=60)
        self.bot = bot
        self.update_view()
    
    def update_view(self):
        self.clear_items()
        
        # Create the Main Layout Container
        main_container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
        
        # Header
        main_container.add_item(TextDisplay("### Bot Statistics"))
        main_container.add_item(Separator())
        
        # Credits Section (with Avatar accessory)
        credits_text = "Developed and managed by **[wizàrd](https://discord.com/users/1463384068702998710)** I'm a music bot."
        if self.bot.user and self.bot.user.display_avatar:
            header_section = Section(
                TextDisplay(credits_text),
                accessory=Thumbnail(self.bot.user.display_avatar.url)
            )
            main_container.add_item(header_section)
        else:
            main_container.add_item(TextDisplay(credits_text))
        
        # Statistics Logic
        total_servers = len(self.bot.guilds)
        total_users = sum(guild.member_count or 0 for guild in self.bot.guilds)
        total_channels = sum(len(guild.channels) for guild in self.bot.guilds)
        
        stats_content = (
            "### Statistics\n\n"
            f"> **Servers**: {total_servers:,}\n"
            f"> **Users**: {total_users:,}\n"
            f"> **Channels**: {total_channels:,}\n"
        )
        main_container.add_item(TextDisplay(stats_content))
        
        # Client Info Logic
        ping_ms = round(self.bot.latency * 1000)
        
        # Safety check for uptime
        utility_cog = self.bot.get_cog('Utility')
        start_time = getattr(utility_cog, 'start_time', time.time())
        uptime_seconds = int(time.time() - start_time)
        
        d = uptime_seconds // 86400
        h = (uptime_seconds % 86400) // 3600
        m = (uptime_seconds % 3600) // 60
        s = uptime_seconds % 60
        
        total_commands = len(list(self.bot.walk_commands()))
        
        client_content = (
            "### Client\n\n"
            f"> **Ping**: `{ping_ms}ms`\n"
            f"> **Uptime**: `{d}d {h}h {m}m {s}s`\n"
            f"> **Commands**: `{total_commands}`\n"
            f"> **Library**: discord.py `{discord.__version__}`"
        )
        main_container.add_item(TextDisplay(client_content))
        main_container.add_item(Separator())
        
        # CREATE BUTTONS INSIDE THE CONTAINER
        button_row = ActionRow()
        
        button_row.add_item(Button(
            label=f"{total_servers} Servers",
            style=ButtonStyle.secondary,
            disabled=True
        ))
        
        button_row.add_item(Button(
            label=f"{total_users:,} Users",
            style=ButtonStyle.secondary,
            disabled=True
        ))
        
        # Add the button row to the container
        main_container.add_item(button_row)
        
        # Add the main container to the view
        self.add_item(main_container)

# --- Prefix Management View ---

class PrefixModal(Modal):
    def __init__(self, action: str, current_prefixes: List[str]):
        super().__init__(title=f"Prefix {action.capitalize()}")
        self.action = action
        self.current_prefixes = current_prefixes
        
        if action == "add":
            self.prefix_input = TextInput(
                label="Enter new prefix(es)",
                placeholder="Example: !, $, > (use commas for multiple)",
                max_length=100
            )
            self.add_item(self.prefix_input)
        elif action == "remove":
            self.prefix_input = TextInput(
                label="Enter prefix to remove",
                placeholder=f"Current: {', '.join(current_prefixes) if current_prefixes else 'None'}",
                max_length=10
            )
            self.add_item(self.prefix_input)
        elif action == "replace":
            self.old_prefix = TextInput(
                label="Prefix to replace",
                placeholder=f"Current: {', '.join(current_prefixes) if current_prefixes else 'None'}",
                max_length=10
            )
            self.new_prefix = TextInput(
                label="New prefix",
                placeholder="Enter new prefix",
                max_length=10
            )
            self.add_item(self.old_prefix)
            self.add_item(self.new_prefix)

    async def on_submit(self, interaction: discord.Interaction):
        # This will be handled in the PrefixView
        await interaction.response.defer()

class PrefixView(LayoutView):
    def __init__(self, ctx: commands.Context, bot, prefixes: List[str]):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.bot = bot
        self.prefixes = prefixes
        self.default_prefix = ","
        
    async def build(self):
        self.clear_items()
        container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
        
        # Title
        container.add_item(TextDisplay("## Manage Prefixes"))
        
        # Display current prefixes
        if self.prefixes:
            formatted = " • ".join([f"`{p}`" for p in self.prefixes])
            container.add_item(TextDisplay(formatted))
        else:
            container.add_item(TextDisplay(f"`{self.default_prefix}` (default)"))
        
        # Show count
        total_prefixes = len(self.prefixes) if self.prefixes else 1
        container.add_item(TextDisplay(f"-# {total_prefixes} of 5 prefixes"))
        
        container.add_item(Separator())
        
        # Create buttons
        button_row = ActionRow()
        
        # Add button
        add_btn = Button(
            label="+",
            style=ButtonStyle.success,
            disabled=len(self.prefixes) >= 5
        )
        add_btn.callback = self.add_prefix
        
        # Remove button
        remove_btn = Button(
            label="-",
            style=ButtonStyle.danger,
            disabled=not self.prefixes
        )
        remove_btn.callback = self.remove_prefix
        
        # Replace button
        replace_btn = Button(
            label="Replace All",
            style=ButtonStyle.secondary,
            disabled=not self.prefixes
        )
        replace_btn.callback = self.replace_prefix
        
        # Reset button
        reset_btn = Button(
            label="Reset to Default",
            style=ButtonStyle.secondary
        )
        reset_btn.callback = self.reset_prefix
        
        button_row.add_item(add_btn)
        button_row.add_item(remove_btn)
        button_row.add_item(replace_btn)
        button_row.add_item(reset_btn)
        
        container.add_item(button_row)
        self.add_item(container)
    
    async def add_prefix(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("You can't use this!", ephemeral=True)
        
        if len(self.prefixes) >= 5:
            return await interaction.response.send_message("Maximum 5 prefixes allowed!", ephemeral=True)
        
        modal = PrefixModal("add", self.prefixes)
        await interaction.response.send_modal(modal)
        
        try:
            await modal.wait()
            input_text = modal.prefix_input.value.strip()
            
            if not input_text:
                return await interaction.followup.send("No prefix provided!", ephemeral=True)
            
            # Split by commas and clean up
            new_prefixes_raw = [item.strip() for item in input_text.split(',')]
            new_prefixes = [p for p in new_prefixes_raw if p]  # Remove empty strings
            
            if not new_prefixes:
                return await interaction.followup.send("No valid prefixes provided!", ephemeral=True)
            
            # Check each prefix
            for new_prefix in new_prefixes:
                if len(new_prefix) > 10:
                    return await interaction.followup.send(f"Prefix `{new_prefix}` too long (max 10 characters)!", ephemeral=True)
                
                if new_prefix in self.prefixes:
                    return await interaction.followup.send(f"Prefix `{new_prefix}` already exists!", ephemeral=True)
            
            # Check total count
            total_after_add = len(self.prefixes) + len(new_prefixes)
            if total_after_add > 5:
                return await interaction.followup.send(f"Maximum 5 prefixes allowed! You have {len(self.prefixes)} and trying to add {len(new_prefixes)} more.", ephemeral=True)
            
            # Add all prefixes
            added_prefixes = []
            for new_prefix in new_prefixes:
                try:
                    # First check if prefix already exists in database
                    existing = await self.bot.db.fetchrow(
                        "SELECT 1 FROM prefixes WHERE guild_id = ? AND prefix = ?",
                        self.ctx.guild.id, new_prefix
                    )
                    
                    if not existing:
                        await self.bot.db.execute(
                            "INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?)",
                            self.ctx.guild.id, new_prefix
                        )
                        self.prefixes.append(new_prefix)
                        added_prefixes.append(new_prefix)
                except Exception as e:
                    if "UNIQUE constraint" in str(e):
                        # Handle the unique constraint - store as comma-separated
                        await self.handle_unique_constraint(new_prefix)
                    else:
                        raise e
            
            # Rebuild view
            await self.build()
            await interaction.followup.edit_message(interaction.message.id, view=self)
            
            if added_prefixes:
                await interaction.followup.send(f"✅ Added prefixes: {', '.join(f'`{p}`' for p in added_prefixes)}", ephemeral=True)
            
        except Exception as e:
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    async def handle_unique_constraint(self, new_prefix: str):
        """Handle database with UNIQUE constraint on guild_id"""
        existing = await self.bot.db.fetchrow(
            "SELECT prefix FROM prefixes WHERE guild_id = ?",
            self.ctx.guild.id
        )
        
        if existing:
            # Parse existing prefixes
            existing_prefixes = existing['prefix'].split(',') if ',' in existing['prefix'] else [existing['prefix']]
            
            # Add new prefix if not already there
            if new_prefix not in existing_prefixes:
                existing_prefixes.append(new_prefix)
            
            # Update as comma-separated string
            prefixes_str = ','.join(existing_prefixes)
            await self.bot.db.execute(
                "UPDATE prefixes SET prefix = ? WHERE guild_id = ?",
                prefixes_str, self.ctx.guild.id
            )
            self.prefixes = existing_prefixes
        else:
            # Insert new
            await self.bot.db.execute(
                "INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?)",
                self.ctx.guild.id, new_prefix
            )
            self.prefixes = [new_prefix]
    
    async def remove_prefix(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("You can't use this!", ephemeral=True)
        
        if not self.prefixes:
            return await interaction.response.send_message("No prefixes to remove!", ephemeral=True)
        
        modal = PrefixModal("remove", self.prefixes)
        await interaction.response.send_modal(modal)
        
        try:
            await modal.wait()
            prefix_to_remove = modal.prefix_input.value.strip()
            
            if not prefix_to_remove:
                return await interaction.followup.send("No prefix provided!", ephemeral=True)
            
            if prefix_to_remove not in self.prefixes:
                return await interaction.followup.send(f"Prefix `{prefix_to_remove}` not found!", ephemeral=True)
            
            # First try to delete individual row
            try:
                await self.bot.db.execute(
                    "DELETE FROM prefixes WHERE guild_id = ? AND prefix = ?",
                    self.ctx.guild.id, prefix_to_remove
                )
                self.prefixes.remove(prefix_to_remove)
            except Exception:
                # If that fails, handle comma-separated storage
                existing = await self.bot.db.fetchrow(
                    "SELECT prefix FROM prefixes WHERE guild_id = ?",
                    self.ctx.guild.id
                )
                
                if existing:
                    existing_prefixes = existing['prefix'].split(',') if ',' in existing['prefix'] else [existing['prefix']]
                    if prefix_to_remove in existing_prefixes:
                        existing_prefixes.remove(prefix_to_remove)
                    
                    if existing_prefixes:
                        prefixes_str = ','.join(existing_prefixes)
                        await self.bot.db.execute(
                            "UPDATE prefixes SET prefix = ? WHERE guild_id = ?",
                            prefixes_str, self.ctx.guild.id
                        )
                        self.prefixes = existing_prefixes
                    else:
                        await self.bot.db.execute(
                            "DELETE FROM prefixes WHERE guild_id = ?",
                            self.ctx.guild.id
                        )
                        self.prefixes = []
            
            # Rebuild view
            await self.build()
            await interaction.followup.edit_message(interaction.message.id, view=self)
            await interaction.followup.send(f"✅ Removed prefix: `{prefix_to_remove}`", ephemeral=True)
            
        except Exception as e:
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    async def replace_prefix(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("You can't use this!", ephemeral=True)
        
        modal = PrefixModal("replace", self.prefixes)
        await interaction.response.send_modal(modal)
        
        try:
            await modal.wait()
            old_prefix = modal.old_prefix.value.strip()
            new_prefix = modal.new_prefix.value.strip()
            
            if not old_prefix or not new_prefix:
                return await interaction.followup.send("Both prefixes are required!", ephemeral=True)
            
            if old_prefix not in self.prefixes:
                return await interaction.followup.send(f"Prefix `{old_prefix}` not found!", ephemeral=True)
            
            if len(new_prefix) > 10:
                return await interaction.followup.send("New prefix too long (max 10 characters)!", ephemeral=True)
            
            if new_prefix in self.prefixes and new_prefix != old_prefix:
                return await interaction.followup.send(f"Prefix `{new_prefix}` already exists!", ephemeral=True)
            
            # Try to update individual row
            try:
                await self.bot.db.execute(
                    "UPDATE prefixes SET prefix = ? WHERE guild_id = ? AND prefix = ?",
                    new_prefix, self.ctx.guild.id, old_prefix
                )
            except Exception:
                # Handle comma-separated storage
                existing = await self.bot.db.fetchrow(
                    "SELECT prefix FROM prefixes WHERE guild_id = ?",
                    self.ctx.guild.id
                )
                
                if existing:
                    existing_prefixes = existing['prefix'].split(',') if ',' in existing['prefix'] else [existing['prefix']]
                    index = existing_prefixes.index(old_prefix)
                    existing_prefixes[index] = new_prefix
                    
                    prefixes_str = ','.join(existing_prefixes)
                    await self.bot.db.execute(
                        "UPDATE prefixes SET prefix = ? WHERE guild_id = ?",
                        prefixes_str, self.ctx.guild.id
                    )
                    self.prefixes = existing_prefixes
            
            # Update local list
            index = self.prefixes.index(old_prefix)
            self.prefixes[index] = new_prefix
            
            # Rebuild view
            await self.build()
            await interaction.followup.edit_message(interaction.message.id, view=self)
            await interaction.followup.send(f"✅ Replaced `{old_prefix}` with `{new_prefix}`", ephemeral=True)
            
        except Exception as e:
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    async def reset_prefix(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("You can't use this!", ephemeral=True)
        
        # Clear all prefixes from database
        await self.bot.db.execute(
            "DELETE FROM prefixes WHERE guild_id = ?",
            self.ctx.guild.id
        )
        
        # Reset to default
        self.prefixes = []
        
        # Rebuild view
        await self.build()
        await interaction.response.edit_message(view=self)
        await interaction.followup.send("✅ Reset to default prefix `,`", ephemeral=True)

# --- UTILITY COG ---

class Utility(commands.Cog):
    def __init__(self, bot: "Antinuke"):
        self.bot = bot
        self.start_time = time.time()
        self.no_pings = AllowedMentions.none()
        self.bot.add_check(self.ignore_check)
        
    def cog_unload(self):
        # Remove the check when cog is unloaded
        self.bot.remove_check(self.ignore_check)
        
    async def cog_load(self):
        """Initialize database tables"""
        await self.bot.db.execute("""
            CREATE TABLE IF NOT EXISTS ignore_channels (
                guild_id INTEGER,
                channel_id INTEGER,
                type TEXT DEFAULT 'channel',
                PRIMARY KEY (guild_id, channel_id)
            )
        """)
        
        await self.bot.db.execute("""
            CREATE TABLE IF NOT EXISTS ignore_whitelist (
                guild_id INTEGER,
                entity_id INTEGER,
                entity_type TEXT,
                PRIMARY KEY (guild_id, entity_id)
            )
        """)

    async def ignore_check(self, ctx):
        """This function actually blocks the commands"""
        if not ctx.guild:
            return True

        # Check if channel is ignored
        ignored = await self.bot.db.fetchrow(
            "SELECT 1 FROM ignore_channels WHERE guild_id = ? AND channel_id = ?",
            ctx.guild.id, ctx.channel.id
        )

        if ignored:
            # Check if user/role is whitelisted
            whitelisted = False
            
            # Check user whitelist
            user_wl = await self.bot.db.fetchrow(
                "SELECT 1 FROM ignore_whitelist WHERE guild_id = ? AND entity_id = ? AND entity_type = 'user'",
                ctx.guild.id, ctx.author.id
            )
            if user_wl:
                whitelisted = True
            
            # Check roles whitelist
            if not whitelisted:
                for role in ctx.author.roles:
                    role_wl = await self.bot.db.fetchrow(
                        "SELECT 1 FROM ignore_whitelist WHERE guild_id = ? AND entity_id = ? AND entity_type = 'role'",
                        ctx.guild.id, role.id
                    )
                    if role_wl:
                        whitelisted = True
                        break
            
            if not whitelisted:
                # Using the defined ServerView
                view = ServerView()
                view.container.add_item(TextDisplay("Commands are disabled in this channel."))
                view.finalize()
                await ctx.send(view=view, delete_after=5)
                return False # This is what actually blocks the command
        
        return True

    async def get_prefixes(self, guild_id: int) -> List[str]:
        """Get all prefixes for a guild"""
        try:
            rows = await self.bot.db.fetch("SELECT prefix FROM prefixes WHERE guild_id = ?", guild_id)
            
            if not rows:
                return [","]  # Default prefix
            
            prefixes = []
            for row in rows:
                prefix_value = row['prefix']
                # Check if it's comma-separated (from unique constraint workaround)
                if ',' in str(prefix_value):
                    prefixes.extend([p.strip() for p in str(prefix_value).split(',') if p.strip()])
                else:
                    prefixes.append(str(prefix_value))
            
            return list(set(prefixes))  # Remove duplicates
        except Exception:
            return [","]  # Default prefix on error

    # Dynamic prefix getter for bot
    async def get_bot_prefix(self, message: discord.Message) -> List[str]:
        """Get prefixes for the bot command handler"""
        if message.guild is None:
            return [","]  # Default for DMs
        
        prefixes = await self.get_prefixes(message.guild.id)
        return prefixes

    @commands.command()
    async def ping(self, ctx: commands.Context):
        await ctx.send(view=SimpleView(f"### 🏓 Latency: `{round(self.bot.latency * 1000)}ms`"))

    @commands.command()
    async def uptime(self, ctx: commands.Context):
        diff = datetime.timedelta(seconds=int(time.time() - self.start_time))
        await ctx.send(view=SimpleView(f"### ⏰ Uptime: `{str(diff).split('.')[0]}`"))

    @commands.command(aliases=["bi", "about"])
    async def botinfo(self, ctx: commands.Context):
        await ctx.send(view=BotInfoView(self.bot), allowed_mentions=self.no_pings)

    @commands.command(name="prefix")
    @commands.has_permissions(manage_guild=True)
    async def prefix(self, ctx: commands.Context):
        """Manage bot prefixes for this server"""
        # Get current prefixes
        prefixes = await self.get_prefixes(ctx.guild.id)
        # Remove default from display if custom prefixes exist
        if len(prefixes) > 1 and "," in prefixes:
            prefixes.remove(",")
        
        # Create and display prefix management view
        prefix_view = PrefixView(ctx, self.bot, prefixes)
        await prefix_view.build()
        await ctx.send(view=prefix_view, allowed_mentions=self.no_pings)

    @commands.command(name="fixprefixdb", aliases=["fixdb"])
    @commands.is_owner()
    async def fix_prefix_db(self, ctx: commands.Context):
        """Fix the database to allow multiple prefixes (Owner only)"""
        try:
            # Check current table structure
            table_info = await self.bot.db.fetch("PRAGMA table_info(prefixes)")
            
            # Check if guild_id has UNIQUE constraint
            has_unique = False
            for col in table_info:
                if col['name'] == 'guild_id' and col['pk'] == 1:
                    has_unique = True
                    break
            
            if has_unique:
                # Create new table without UNIQUE constraint
                await self.bot.db.execute("""
                    CREATE TABLE IF NOT EXISTS prefixes_new (
                        guild_id BIGINT NOT NULL,
                        prefix TEXT NOT NULL,
                        PRIMARY KEY (guild_id, prefix)
                    )
                """)
                
                # Copy data
                await self.bot.db.execute("""
                    INSERT OR IGNORE INTO prefixes_new (guild_id, prefix)
                    SELECT guild_id, prefix FROM prefixes
                """)
                
                # Drop old table
                await self.bot.db.execute("DROP TABLE prefixes")
                
                # Rename new table
                await self.bot.db.execute("ALTER TABLE prefixes_new RENAME TO prefixes")
                
                await ctx.send(view=SimpleView("✅ Database fixed! Now supports multiple prefixes per guild."))
            else:
                await ctx.send(view=SimpleView("✅ Database already supports multiple prefixes!"))
        except Exception as e:
            await ctx.send(view=SimpleView(f"❌ Error fixing database: {str(e)}"))

    @commands.group(name="ignore", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def ignore(self, ctx):
        """Ignore system commands"""
        pass
    
    @ignore.group(name="channel", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def ignore_channel(self, ctx):
        """Ignore channel commands"""
        await ctx.send("Use: `ignore channel add/remove/list`")
    
    @ignore_channel.command(name="add")
    @commands.has_permissions(manage_guild=True)
    async def ignore_channel_add(self, ctx, channel: discord.TextChannel = None):
        """Add channel to ignore list"""
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO ignore_channels (guild_id, channel_id, type) VALUES (?, ?, ?)",
            ctx.guild.id, channel.id, 'channel'
        )
        
        view = ServerView()
        view.container.add_item(TextDisplay(f"Added `{channel.name}` to ignore list"))
        view.finalize()
        await ctx.send(view=view)
    
    @ignore_channel.command(name="remove")
    @commands.has_permissions(manage_guild=True)
    async def ignore_channel_remove(self, ctx, channel: discord.TextChannel = None):
        """Remove channel from ignore list"""
        channel = channel or ctx.channel
        
        # We need to know if something was deleted to show the correct message
        check = await self.bot.db.fetchrow(
            "SELECT 1 FROM ignore_channels WHERE guild_id = ? AND channel_id = ?",
            ctx.guild.id, channel.id
        )

        await self.bot.db.execute(
            "DELETE FROM ignore_channels WHERE guild_id = ? AND channel_id = ?",
            ctx.guild.id, channel.id
        )
        
        view = ServerView()
        if check:
            view.container.add_item(TextDisplay(f"Removed `{channel.name}` from ignore list"))
        else:
            view.container.add_item(TextDisplay(f"`{channel.name}` not in ignore list"))
        view.finalize()
        await ctx.send(view=view)
    
    @ignore_channel.command(name="list")
    @commands.has_permissions(manage_guild=True)
    async def ignore_channel_list(self, ctx):
        """List ignored channels"""
        rows = await self.bot.db.fetch(
            "SELECT channel_id FROM ignore_channels WHERE guild_id = ? AND type = 'channel'",
            ctx.guild.id
        )
        
        view = ServerView()
        if not rows:
            view.container.add_item(TextDisplay("No channels ignored"))
        else:
            channels = []
            for row in rows:
                channel = ctx.guild.get_channel(row['channel_id'])
                if channel:
                    channels.append(f"• `{channel.name}`")
                else:
                    channels.append(f"• Unknown Channel ({row['channel_id']})")
            view.container.add_item(TextDisplay(f"Ignored Channels:\n" + "\n".join(channels)))
        
        view.finalize()
        await ctx.send(view=view)
    
    @ignore.group(name="wl", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def ignore_wl(self, ctx):
        """Ignore whitelist commands"""
        pass
    
    @ignore_wl.command(name="add")
    @commands.has_permissions(manage_guild=True)
    async def ignore_wl_add(self, ctx, entity: Union[discord.Role, discord.Member]):
        """Add role/user to ignore whitelist"""
        entity_type = "role" if isinstance(entity, discord.Role) else "user"
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO ignore_whitelist (guild_id, entity_id, entity_type) VALUES (?, ?, ?)",
            ctx.guild.id, entity.id, entity_type
        )
        
        view = ServerView()
        view.container.add_item(TextDisplay(
            f"Added `{entity.name}` to ignore whitelist"
        ))
        view.finalize()
        await ctx.send(view=view)
    
    @ignore_wl.command(name="remove")
    @commands.has_permissions(manage_guild=True)
    async def ignore_wl_remove(self, ctx, entity: Union[discord.Role, discord.Member]):
        """Remove role/user from ignore whitelist"""
        entity_type = "role" if isinstance(entity, discord.Role) else "user"
        
        check = await self.bot.db.fetchrow(
            "SELECT 1 FROM ignore_whitelist WHERE guild_id = ? AND entity_id = ? AND entity_type = ?",
            ctx.guild.id, entity.id, entity_type
        )

        await self.bot.db.execute(
            "DELETE FROM ignore_whitelist WHERE guild_id = ? AND entity_id = ? AND entity_type = ?",
            ctx.guild.id, entity.id, entity_type
        )
        
        view = ServerView()
        if check:
            view.container.add_item(TextDisplay(
                f"Removed `{entity.name}` from ignore whitelist"
            ))
        else:
            view.container.add_item(TextDisplay(
                f"`{entity.name}` not in ignore whitelist"
            ))
        view.finalize()
        await ctx.send(view=view)
    
    @ignore_wl.command(name="list")
    @commands.has_permissions(manage_guild=True)
    async def ignore_wl_list(self, ctx):
        """List ignore whitelist"""
        rows = await self.bot.db.fetch(
            "SELECT entity_id, entity_type FROM ignore_whitelist WHERE guild_id = ?",
            ctx.guild.id
        )
        
        view = ServerView()
        if not rows:
            view.container.add_item(TextDisplay("No entities in ignore whitelist"))
        else:
            entities = []
            for row in rows:
                if row['entity_type'] == 'role':
                    entity = ctx.guild.get_role(row['entity_id'])
                    if entity:
                        entities.append(f"• Role: `{entity.name}`")
                    else:
                        entities.append(f"• Role: Unknown ({row['entity_id']})")
                else:  # user
                    entity = ctx.guild.get_member(row['entity_id'])
                    if entity:
                        entities.append(f"• User: `{entity.name}`")
                    else:
                        entities.append(f"• User: Unknown ({row['entity_id']})")
            view.container.add_item(TextDisplay(f"Ignore Whitelist:\n" + "\n".join(entities)))
        
        view.finalize()
        await ctx.send(view=view)
        
async def setup(bot: "Antinuke"):
    cog = Utility(bot)
    
    # Set the bot's command prefix getter
    bot.command_prefix = commands.when_mentioned_or(cog.get_bot_prefix)
    
    await bot.add_cog(cog)