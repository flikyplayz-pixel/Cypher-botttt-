from discord import Embed, Message, AuditLogAction
from discord.ext.commands import Cog, Bot
from typing import TYPE_CHECKING
import datetime

if TYPE_CHECKING:
    from main import Antinuke

class Listeners(Cog):
    def __init__(self, bot: "Antinuke"):
        self.bot = bot

    @Cog.listener()
    async def on_member_join(self, member):
        # Emergency Mode Logic
        antinuke_cog = self.bot.get_cog("Antinuke")
        if antinuke_cog:
            if await antinuke_cog.is_whitelisted(member.guild.id, member.id):
                return

        premium = await self.bot.db.fetchrow("SELECT emergency FROM premium WHERE user_id = ?", member.guild.owner_id)
        if premium and premium.emergency:
            try:
                await member.send("This server is currently in **Emergency Mode**. Please try joining later.")
                await member.kick(reason="Emergency Mode Enabled")
            except:
                pass

    @Cog.listener()
    async def on_guild_channel_create(self, channel):
        await self.handle_nightmode_event(channel.guild, f"Channel Create: {channel.name}", lambda: channel.delete(), target_id=channel.id, action_type=AuditLogAction.channel_create)

    @Cog.listener()
    async def on_guild_role_create(self, role):
        await self.handle_nightmode_event(role.guild, f"Role Create: {role.name}", lambda: role.delete(), target_id=role.id, action_type=AuditLogAction.role_create)

    @Cog.listener()
    async def on_guild_update(self, before, after):
        await self.handle_nightmode_event(after, "Guild Update", action_type=AuditLogAction.guild_update)

    @Cog.listener()
    async def on_webhook_update(self, channel):
        await self.handle_nightmode_event(channel.guild, "Webhook Update", action_type=AuditLogAction.webhook_create)

    async def handle_nightmode_event(self, guild, reason, revert_action=None, target_id=None, action_type=None):
        premium = await self.bot.db.fetchrow("SELECT nightmode FROM premium WHERE user_id = ?", guild.owner_id)
        if not premium or not premium.nightmode:
            return

        now = datetime.datetime.now().hour
        if not (now >= 22 or now <= 6):
            return

        # Check for whitelist/admin immunity
        if action_type:
            antinuke_cog = self.bot.get_cog("Antinuke")
            async for entry in guild.audit_logs(limit=1, action=action_type):
                # If we have a target_id, make sure this log entry is for that target
                if target_id and entry.target.id != target_id:
                    continue
                
                if antinuke_cog and await antinuke_cog.is_whitelisted(guild.id, entry.user.id):
                    return

        if revert_action:
            try:
                await revert_action()
            except:
                pass

    @Cog.listener()
    async def on_noprefix_command(self, message: Message, command_name: str):
        # You can add logging or a specific response for noprefix usage here
        # For now, we'll just log it to the console
        import loguru
        loguru.logger.info(f"Noprefix command '{command_name}' used by {message.author} in {message.guild}")

async def setup(bot: "Antinuke"):
    await bot.add_cog(Listeners(bot))
