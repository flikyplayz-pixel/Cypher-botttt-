import discord
from discord.ext.commands import command, group, Context, Cog
from discord import Member, User, Guild, TextChannel, File
from discord.ui import LayoutView, TextDisplay, Container, ActionRow, Separator, Button
from typing import Union, TYPE_CHECKING
import sys
import os
import zipfile
import asyncio

if TYPE_CHECKING:
    from main import Antinuke

class DevUI:
    @staticmethod
    def create_view(title: str, content: str):
        """Helper to create the custom UI layout used in premium.py"""
        view = LayoutView()
        container = Container()
        container.add_item(TextDisplay(f"### {title}\n{content}"))
        view.add_item(container)
        return view

# --- PAGINATED SERVERS UI ---
class ServerPagination(LayoutView):
    def __init__(self, ctx, guilds):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.guilds = guilds
        self.per_page = 10
        self.current_page = 0
        self.total_pages = (len(guilds) - 1) // 10 + 1

    async def build(self):
        self.clear_items()
        container = Container()
        
        start = self.current_page * 10
        end = start + 10
        chunk = self.guilds[start:end]
        
        server_list = "\n".join([f"**{i+start+1}.** {g.name} | `{g.id}` ({g.member_count})" for i, g in enumerate(chunk)])
        
        container.add_item(TextDisplay(
            f"### Bot Servers (Page {self.current_page + 1}/{self.total_pages})\n"
            f"Total Guilds: **{len(self.guilds)}**\n\n"
            f"{server_list}"
        ))
        
        if self.total_pages > 1:
            row = ActionRow()
            back_btn = Button(label="Back", disabled=(self.current_page == 0))
            back_btn.callback = self.prev_page
            
            next_btn = Button(label="Next", disabled=(self.current_page == self.total_pages - 1))
            next_btn.callback = self.next_page
            
            row.add_item(back_btn)
            row.add_item(next_btn)
            container.add_item(row)
            
        self.add_item(container)

    async def prev_page(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.current_page -= 1
        await self.build()
        await interaction.response.edit_message(view=self)

    async def next_page(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.current_page += 1
        await self.build()
        await interaction.response.edit_message(view=self)

class Developer(Cog):
    def __init__(self, bot: "Antinuke"):
        self.bot = bot

    async def cog_check(self, ctx: Context):
        return ctx.author.id in self.bot.owner_ids

    async def bot_check(self, ctx: Context):
        """Global blacklist check - prevents blacklisted users/guilds from using the bot"""
        # User Check
        user_bl = await self.bot.db.fetchrow("SELECT 1 FROM blacklist WHERE object_id = ? AND object_type = 'user'", ctx.author.id)
        if user_bl: return False
        
        # Guild Check
        if ctx.guild:
            guild_bl = await self.bot.db.fetchrow("SELECT 1 FROM blacklist WHERE object_id = ? AND object_type = 'guild'", ctx.guild.id)
            if guild_bl: return False
                
        # Channel Check
        chan_bl = await self.bot.db.fetchrow("SELECT 1 FROM blacklist WHERE object_id = ? AND object_type = 'textchannel'", ctx.channel.id)
        if chan_bl: return False

        return True

    @command(name="blacklist", aliases=("bl",))
    async def blacklist(self, ctx: Context, *, object_: Union[Member, User, Guild, TextChannel]):
        object_type = str(type(object_)).split(".")[1].lower().replace("member", "user")
        await self.bot.db.execute("INSERT OR IGNORE INTO blacklist (object_id, object_type) VALUES(?, ?)", object_.id, object_type)
        content = f"Blacklisted {object_type}: **{object_.name if hasattr(object_, 'name') else object_.id}**"
        await ctx.send(view=DevUI.create_view("Blacklist", content))
    
    @command(name="unblacklist", aliases=("unbl", "ubl",))
    async def unblacklist(self, ctx: Context, *, object_: Union[Member, User, Guild, TextChannel]):
        object_type = str(type(object_)).split(".")[1].lower().replace("member", "user")
        await self.bot.db.execute("DELETE FROM blacklist WHERE object_id = ? AND object_type = ?", object_.id, object_type)
        content = f"Unblacklisted {object_type}: **{object_.name if hasattr(object_, 'name') else object_.id}**"
        await ctx.send(view=DevUI.create_view("Unblacklist", content))

    @command(name="servers")
    async def servers(self, ctx: Context):
        guilds = sorted(self.bot.guilds, key=lambda g: g.member_count, reverse=True)
        view = ServerPagination(ctx, guilds)
        await view.build()
        await ctx.send(view=view)

    @command(name="ginv")
    async def ginv(self, ctx: Context, guild_id: int):
        guild = self.bot.get_guild(guild_id)
        if not guild: return await ctx.send("Guild not found.")
        try:
            invite = await guild.text_channels[0].create_invite(max_age=3600)
            await ctx.send(view=DevUI.create_view("Invite Generated", f"Link: {invite.url}"))
        except:
            await ctx.send("Could not create invite.")

    @command(name="sleave")
    async def sleave(self, ctx: Context, guild_id: int):
        guild = self.bot.get_guild(guild_id)
        if not guild: return await ctx.send("Guild not found.")
        await guild.leave()
        await ctx.send(view=DevUI.create_view("Guild Leave", f"Successfully left **{guild.name}**"))

    @group(name="coin", invoke_without_command=True)
    async def coin(self, ctx: Context):
        await ctx.send(view=DevUI.create_view("Coins Management", "Commands: `add`, `remove`"))

    @coin.command(name="add")
    async def coins_add(self, ctx: Context, user: Union[Member, User], amount: int):
        await self.bot.db.execute("""
            INSERT INTO economy (user_id, coins) VALUES (?, ?) 
            ON CONFLICT(user_id) DO UPDATE SET coins = coins + ?
        """, user.id, amount, amount)
        await ctx.send(view=DevUI.create_view("Economy Update", f"Added `{amount}` coins to {user.mention}"))

    @coin.command(name="remove")
    async def coins_remove(self, ctx: Context, user: Union[Member, User], amount: int):
        await self.bot.db.execute("UPDATE economy SET coins = coins - ? WHERE user_id = ?", amount, user.id)
        await ctx.send(view=DevUI.create_view("Economy Update", f"Removed `{amount}` coins from {user.mention}"))

    @command(name="restart")
    async def restart(self, ctx: Context):
        await ctx.send(view=DevUI.create_view("System", "Restarting bot process..."))
        os.execv(sys.executable, ['python'] + sys.argv)

    @command(name="backup")
    async def backup(self, ctx: Context):
        msg = await ctx.send(view=DevUI.create_view("Backup", "Compressing files..."))
        zip_name = "full_backup.zip"
        
        try:
            with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk('.'):
                    # EXCLUDE .local and .cache
                    dirs[:] = [d for d in dirs if d not in ('.local', '.cache', '__pycache__', '.git', 'venv')]
                    for file in files:
                        if file == zip_name: continue
                        file_path = os.path.join(root, file)
                        zipf.write(file_path, os.path.relpath(file_path, '.'))

            await ctx.author.send(content="Backup file generated:", file=File(zip_name))
            await msg.edit(view=DevUI.create_view("Backup", "Success! Check your DMs."))
        except Exception as e:
            await msg.edit(view=DevUI.create_view("Backup Error", str(e)))
        finally:
            if os.path.exists(zip_name): os.remove(zip_name)

async def setup(bot: "Antinuke"):
    await bot.add_cog(Developer(bot))