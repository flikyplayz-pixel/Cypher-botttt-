import discord
import asyncio
import datetime
from typing import List, Union, Optional
from discord import SelectOption, Interaction, ButtonStyle, AllowedMentions, PartialEmoji
from discord.ui import Button, Select, LayoutView, TextDisplay, Container, ActionRow, Separator, Section, Thumbnail
from discord.ext import commands
from discord.ext.commands import command, Context, Cog, Group

# --- UI Components ---

class HelpLayout(LayoutView):
    def __init__(self, ctx: Context, bot):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.bot = bot
        
        # Get all available categories
        self.all_categories = self.get_all_categories()
        
        # Start with first category selected if categories exist
        self.current_category = self.all_categories[0] if self.all_categories else None
    
    def get_all_categories(self):
        """Get all available categories sorted alphabetically"""
        categories = []
        for cog_name, cog in sorted(self.bot.cogs.items(), key=lambda x: x[0]):
            if cog_name in ("Jishaku", "Developer") or getattr(cog, "hidden", False):
                continue
            
            cmds = [c for c in cog.get_commands() if not c.hidden]
            if cmds:
                categories.append(cog.qualified_name)
        return categories
    
    async def build(self):
        self.clear_items()
        container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
        
        # Fetch server prefixes from database
        server_prefixes = await self.get_server_prefixes()
        
        # Format prefixes for display
        if server_prefixes:
            prefix_display = " • ".join([f"`{p}`" for p in server_prefixes])
        else:
            prefix_display = f"`{self.bot.default_prefix or ','}` (default)"
        
        # Always show category buttons at the top (grouped in rows of 5)
        if self.all_categories:
            # Split categories into chunks of 5 for multiple rows
            chunk_size = 5
            category_chunks = [self.all_categories[i:i + chunk_size] 
                              for i in range(0, len(self.all_categories), chunk_size)]
            
            for chunk in category_chunks:
                categories_row = ActionRow()
                for category_name in chunk:
                    is_active = category_name == self.current_category
                    category_btn = Button(
                        label=category_name[:15],  # Limit label length
                        style=ButtonStyle.primary if is_active else ButtonStyle.secondary,
                        custom_id=f"catbtn_{category_name}"
                    )
                    category_btn.callback = self.switch_category
                    categories_row.add_item(category_btn)
                
                container.add_item(categories_row)
            
            container.add_item(Separator())
        
        if not self.all_categories:
            # No categories found
            container.add_item(TextDisplay("### No Commands Available"))
            container.add_item(TextDisplay("-# No command categories were found."))
        else:
            # Show current category's commands
            cog = None
            for cog_name, cog_obj in self.bot.cogs.items():
                if cog_obj.qualified_name == self.current_category:
                    cog = cog_obj
                    break
            
            if cog:
                # Header with category name and prefixes
                container.add_item(TextDisplay(f"### Flash Commands ({cog.qualified_name})"))
                container.add_item(TextDisplay(f"-# Prefixes: {prefix_display}"))
                container.add_item(Separator())
                
                # Get commands for this category
                cmds = sorted([c for c in cog.get_commands() if not c.hidden], key=lambda x: x.name)
                
                if cmds:
                    # Display each command
                    for cmd in cmds:
                        # Build aliases string
                        aliases_str = ""
                        if hasattr(cmd, 'aliases') and cmd.aliases:
                            aliases_str = f" ({', '.join(cmd.aliases)})"
                        
                        # Build command display
                        command_display = f"**/{cmd.name}**{aliases_str} - {cmd.description or 'No description provided.'}"
                        container.add_item(TextDisplay(command_display))
                else:
                    container.add_item(TextDisplay("-# No commands available in this category."))
        
        container.add_item(Separator())
        
        # Support and invite buttons
        bottom_row = ActionRow()
        
        invite_btn = Button(
            label="Invite",
            style=ButtonStyle.link,
            url=f"https://discord.com/api/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot",
            emoji=PartialEmoji(name="link", id=1466748828177797226)
        )
        
        support_btn = Button(
            label="Support",
            style=ButtonStyle.link,
            url="https://discord.gg/KAWbBzPHsd",
            emoji=PartialEmoji(name="support", id=1466748789992984792)
        )
        
        bottom_row.add_item(invite_btn)
        bottom_row.add_item(support_btn)
        
        if self.all_categories:
            container.add_item(TextDisplay("-# Click category buttons to explore commands"))
        container.add_item(TextDisplay("-# Need help? Join our support server!"))
        container.add_item(bottom_row)
        
        self.add_item(container)
    
    async def get_server_prefixes(self):
        """Fetch server-specific prefixes from database"""
        try:
            # Check if database connection exists
            if not hasattr(self.bot, 'db'):
                return []
            
            # Try to fetch prefixes (handle both comma-separated and individual rows)
            rows = await self.bot.db.fetch(
                "SELECT prefix FROM prefixes WHERE guild_id = $1",
                self.ctx.guild.id
            )
            
            if not rows:
                return []
            
            # Process prefixes - handle both formats
            prefixes = []
            for row in rows:
                prefix_value = row['prefix']
                # Check if it's comma-separated
                if ',' in prefix_value:
                    prefixes.extend([p.strip() for p in prefix_value.split(',') if p.strip()])
                else:
                    prefixes.append(prefix_value)
            
            return list(dict.fromkeys(prefixes))  # Remove duplicates while preserving order
            
        except Exception as e:
            print(f"Error fetching prefixes: {e}")
            return []
    
    async def switch_category(self, interaction: Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("This is not your menu!", ephemeral=True)
        
        custom_id = interaction.data.get('custom_id', '')
        if custom_id.startswith('catbtn_'):
            self.current_category = custom_id.replace('catbtn_', '')
            await self.build()
            await interaction.response.edit_message(view=self)

class InfoView(LayoutView):
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
    
    def finalize(self):
        self.add_item(self.container)

class ProfileView(LayoutView):
    def __init__(self, ctx, member: discord.Member, stats: dict):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.member = member
        self.stats = stats
        self.current_page = "home"
        
        # CONFIGURE YOUR BADGE ROLES HERE
        self.badge_roles = {
            123456789012345678: "Staff",
            181827182711771822: "Trial Staff",
            223456789012345678: "Booster",
            171827827271718171: "Premium User",
            323456789012345678: "VIP",
            423456789012345678: "Artist"
        }
        self.update_view()

    def update_view(self):
        self.clear_items()
        container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
        
        if self.current_page == "home":
            container.add_item(TextDisplay(f"### {self.member.display_name}'s Profile"))
            container.add_item(Separator())
            content = (
                f"> **User**: {self.member.mention}\n"
                f"> **ID**: `{self.member.id}`\n"
                f"> **Joined**: <t:{int(self.member.joined_at.timestamp())}:R>"
            )
            container.add_item(Section(TextDisplay(content), accessory=Thumbnail(self.member.display_avatar.url)))

        elif self.current_page == "badges":
            container.add_item(TextDisplay("### Collected Badges"))
            container.add_item(Separator())
            
            # Filter roles the user actually has
            user_badges = [emoji for role_id, emoji in self.badge_roles.items() if self.member.get_role(role_id)]
            
            if self.member.id == 1463384068702998710:
                user_badges.insert(0, "**Developer**")

            badge_text = "\n".join([f"• {b}" for b in user_badges]) if user_badges else "_No badges collected yet._"
            container.add_item(TextDisplay(badge_text))

        elif self.current_page == "leaderboard":
            container.add_item(TextDisplay("### Personal Statistics"))
            container.add_item(Separator())
            stats_content = (
                f"🎵 **Songs Played**: `{self.stats['songs']:,}`\n"
                f"⌨️ **Commands Run**: `{self.stats['commands']:,}`\n\n"
                "-# Stats are tracked globally across all servers."
            )
            container.add_item(TextDisplay(stats_content))

        # Navigation Row
        row = ActionRow()
        row.add_item(Button(label="Home", style=ButtonStyle.primary if self.current_page == "home" else ButtonStyle.secondary, custom_id="p_home"))
        row.add_item(Button(label="Badges", style=ButtonStyle.primary if self.current_page == "badges" else ButtonStyle.secondary, custom_id="p_badges"))
        row.add_item(Button(label="Stats", style=ButtonStyle.primary if self.current_page == "leaderboard" else ButtonStyle.secondary, custom_id="p_stats"))
        
        # Map callbacks manually since we are using custom_ids for cleaner logic
        for btn in row.children:
            btn.callback = self.handle_navigation

        container.add_item(Separator())
        container.add_item(row)
        self.add_item(container)

    async def handle_navigation(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("This is not your profile.", ephemeral=True)
        
        cid = interaction.data['custom_id']
        if cid == "p_home": self.current_page = "home"
        elif cid == "p_badges": self.current_page = "badges"
        elif cid == "p_stats": self.current_page = "leaderboard"
        
        self.update_view()
        await interaction.response.edit_message(view=self)

# --- Information Cog ---

class Information(Cog):
    def __init__(self, bot):
        self.bot = bot
        self.no_mentions = AllowedMentions(users=False, roles=False, everyone=False)
        
    async def cog_load(self):
        """Initialize database tables for ignores, user statistics, and prefixes"""
        # User stats table
        await self.bot.db.execute("""
            CREATE TABLE IF NOT EXISTS user_stats (
                user_id BIGINT PRIMARY KEY,
                songs_played INTEGER DEFAULT 0,
                commands_used INTEGER DEFAULT 0
            )
        """)
        
        # Prefixes table (if not already created by Utility cog)
        await self.bot.db.execute("""
            CREATE TABLE IF NOT EXISTS prefixes (
                guild_id BIGINT,
                prefix TEXT,
                PRIMARY KEY (guild_id, prefix)
            )
        """)

    @command(name="help", description="Get info about a command or explore categories")
    async def help(self, ctx: Context, *, query: str = None):
        if query:
            # Check if command exists
            cmd = self.bot.get_command(query)
            if cmd:
                # Fetch server prefixes
                prefixes = await self.get_server_prefixes(ctx.guild)
                if not prefixes:
                    prefixes = [self.bot.default_prefix or ',']
                
                # Create simple command info with prefixes
                prefix_display = " • ".join([f"`{p}`" for p in prefixes])
                aliases = ", ".join(cmd.aliases) if cmd.aliases else "None"
                
                embed = discord.Embed(
                    title=f"Command: {cmd.qualified_name}",
                    description=cmd.description or "No description provided.",
                    color=discord.Color.blue()
                )
                embed.add_field(name="Prefixes", value=prefix_display, inline=False)
                embed.add_field(name="Usage", value=f"`{prefixes[0]}{cmd.qualified_name} {cmd.signature}`", inline=False)
                embed.add_field(name="Aliases", value=f"`{aliases}`", inline=False)
                return await ctx.send(embed=embed)
            else:
                return await ctx.send(f"Command `{query}` not found.")
        
        help_view = HelpLayout(ctx, self.bot)
        await help_view.build()
        await ctx.send(view=help_view)
    
    async def get_server_prefixes(self, guild):
        """Helper method to fetch server prefixes"""
        try:
            rows = await self.bot.db.fetch(
                "SELECT prefix FROM prefixes WHERE guild_id = $1",
                guild.id
            )
            
            if not rows:
                return []
            
            prefixes = []
            for row in rows:
                prefix_value = row['prefix']
                if ',' in prefix_value:
                    prefixes.extend([p.strip() for p in prefix_value.split(',') if p.strip()])
                else:
                    prefixes.append(prefix_value)
            
            return list(dict.fromkeys(prefixes))
            
        except Exception:
            return []

    @command(name="invite")
    async def invite(self, ctx: Context):
        view = InfoView()
        btn_row = ActionRow()
        btn_row.add_item(Button(label="Admin (Recommended)", style=ButtonStyle.link, url=f"https://discord.com/api/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot", emoji=PartialEmoji(name="link", id=1466748828177797226)))
        btn_row.add_item(Button(label="Basic Invite", style=ButtonStyle.link, url=f"https://discord.com/oauth2/authorize?client_id=1463533899878760498&permissions=352947732073537&integration_type=0&scope=bot+applications.commands", emoji=PartialEmoji(name="link", id=1466748828177797226)))
        view.container.add_item(btn_row)
        view.finalize()
        await ctx.send(view=view)

    @command(name="support")
    async def support(self, ctx: Context):
        view = InfoView()
        btn_row = ActionRow()
        btn_row.add_item(Button(label="Support Server", style=ButtonStyle.link, url="https://discord.gg/KAWbBzPHsd", emoji=PartialEmoji(name="support", id=1466748789992984792)))
        view.container.add_item(btn_row)
        view.finalize()
        await ctx.send(view=view)

    @command(name="vote")
    async def vote(self, ctx: Context):
        view = InfoView()
        btn_row = ActionRow()
        btn_row.add_item(Button(label="Vote on top.gg", style=ButtonStyle.link, url=f"https://top.gg/bot/{self.bot.user.id}/vote", emoji=PartialEmoji(name="vote", id=1466748756958384343)))
        view.container.add_item(btn_row)
        view.finalize()
        await ctx.send(view=view)
        
    @commands.command(name="profile", aliases=["ui", "userinfo"])
    async def profile(self, ctx: commands.Context, member: discord.Member = None):
        """View user profile, badges, and music stats"""
        member = member or ctx.author
        
        # Fetch data from DB (Ensure the table exists)
        row = await self.bot.db.fetchrow(
            "SELECT songs_played, commands_used FROM user_stats WHERE user_id = $1", 
            member.id
        )
        
        stats = {
            'songs': row['songs_played'] if row else 0,
            'commands': row['commands_used'] if row else 0
        }
        
        view = ProfileView(ctx, member, stats)
        await ctx.send(view=view, allowed_mentions=self.no_mentions)
        
    @Cog.listener()
    async def on_command_completion(self, ctx):
        """Increments the command counter in the database"""
        await self.bot.db.execute("""
            INSERT INTO user_stats (user_id, commands_used) 
            VALUES ($1, 1) 
            ON CONFLICT(user_id) 
            DO UPDATE SET commands_used = user_stats.commands_used + 1
        """, ctx.author.id)

async def setup(bot):
    await bot.add_cog(Information(bot))