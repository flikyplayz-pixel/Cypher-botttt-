from discord.ext import commands
import discord
from discord import SelectOption, ButtonStyle, AllowedMentions
from discord.ui import LayoutView, TextDisplay, Container, Select, ActionRow, Separator, Button
from typing import Union, TYPE_CHECKING
import config
import aiohttp
import base64
import asyncio
from datetime import datetime, timedelta
from collections import defaultdict

if TYPE_CHECKING:
    from main import Antinuke

class PremiumUI:
    @staticmethod
    def create_simple_view(title: str, content: str):
        "Create a simple UI view matching the layout style"
        view = LayoutView()
        container = Container(accent_color=0xFFFFFF)
        container.add_item(TextDisplay(f"### {title}\n{content}"))
        view.add_item(container)
        return view

async def get_image_bytes(ctx, url: str = None):
    if ctx.message.attachments:
        return await ctx.message.attachments[0].read()
    elif url:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    return await resp.read()
    return None

def to_base64_image(image_bytes: bytes) -> str:
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:image/png;base64,{encoded}"

# --- PAGINATION FOR PREMIUM LIST ---
class PremiumListPagination(LayoutView):
    def __init__(self, ctx, users_formatted):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.users_formatted = users_formatted
        self.per_page = 10
        self.current_page = 0
        self.pages = [users_formatted[i:i + self.per_page] for i in range(0, len(users_formatted), self.per_page)]

    async def build(self):
        self.clear_items()
        container = Container(accent_color=0xFFFFFF)
        total_pages = len(self.pages)
        current_list = "\n".join(self.pages[self.current_page])
        container.add_item(TextDisplay(f"### Premium Users (Page {self.current_page + 1}/{total_pages})\nTotal Active: **{len(self.users_formatted)}**\n\n{current_list}"))
        if total_pages > 1:
            button_row = ActionRow()
            prev_btn = Button(label="Back", style=ButtonStyle.gray, disabled=(self.current_page == 0))
            prev_btn.callback = self.previous_page
            next_btn = Button(label="Next", style=ButtonStyle.gray, disabled=(self.current_page == total_pages - 1))
            next_btn.callback = self.next_page
            button_row.add_item(prev_btn)
            button_row.add_item(next_btn)
            container.add_item(button_row)
        self.add_item(container)

    async def previous_page(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.current_page -= 1
        await self.build()
        await interaction.response.edit_message(view=self, allowed_mentions=AllowedMentions.none())

    async def next_page(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.current_page += 1
        await self.build()
        await interaction.response.edit_message(view=self, allowed_mentions=AllowedMentions.none())

# --- DURATION SELECTION UI (ADMIN ONLY) ---
class PremiumDurationSelect(LayoutView):
    def __init__(self, ctx, target_user):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.target_user = target_user
        self.duration_days = None
        self.selected_duration = None

    async def build(self):
        self.clear_items()
        options = [
            SelectOption(label="7 Days (1 Week)", value="7"),
            SelectOption(label="28 Days (1 Month)", value="28"),
            SelectOption(label="180 Days (6 Months)", value="180"),
            SelectOption(label="365 Days (1 Year)", value="365")
        ]
        select_menu = Select(placeholder="Select premium duration...", options=options)
        select_menu.callback = self.select_duration
        container = Container(accent_color=0xFFFFFF)
        if self.selected_duration:
            container.add_item(TextDisplay(f"### Premium Selection\n**User:** {self.target_user.mention}\n**Duration:** {self.selected_duration} days"))
            button_row = ActionRow()
            confirm_btn = Button(label="Confirm", style=ButtonStyle.green)
            confirm_btn.callback = self.confirm_selection
            cancel_btn = Button(label="Cancel", style=ButtonStyle.red)
            cancel_btn.callback = self.cancel_selection
            button_row.add_item(confirm_btn)
            button_row.add_item(cancel_btn)
            container.add_item(button_row)
        else:
            container.add_item(TextDisplay(f"### Premium Selection\nSelect duration for {self.target_user.mention}:"))
            dropdown_row = ActionRow()
            dropdown_row.add_item(select_menu)
            container.add_item(dropdown_row)
        self.add_item(container)

    async def select_duration(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.duration_days = int(interaction.data['values'][0])
        self.selected_duration = str(self.duration_days)
        await self.build()
        await interaction.response.edit_message(view=self, allowed_mentions=AllowedMentions.none())

    async def confirm_selection(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        expires_ts = (datetime.utcnow() + timedelta(days=self.duration_days)).timestamp()
        await self.ctx.bot.db.execute("INSERT INTO premium (user_id, expires_at) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET expires_at = ?", self.target_user.id, expires_ts, expires_ts)
        await self.ctx.cog.load_premium_cache()
        await interaction.response.edit_message(view=PremiumUI.create_simple_view("Success", f"Premium added to {self.target_user.mention}"), allowed_mentions=AllowedMentions.none())

    async def cancel_selection(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        self.selected_duration = None
        await self.build()
        await interaction.response.edit_message(view=self, allowed_mentions=AllowedMentions.none())

# --- COIN SHOP VIEW ---
class PremiumBuyView(LayoutView):
    def __init__(self, ctx):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.prices = {"7": 500, "28": 1500, "180": 7000, "365": 12000}

    async def build(self):
        self.clear_items()
        container = Container(accent_color=0xFFFFFF)
        row = await self.ctx.bot.db.fetchrow("SELECT coins FROM economy WHERE user_id = ?", self.ctx.author.id)
        balance = row['coins'] if row else 0
        shop_text = f"### Premium Shop\n**Balance:** {self.ctx.author.mention} (`{balance}` coins)\n\n• **1 Week:** 500\n• **1 Month:** 1500\n• **6 Months:** 7000\n• **1 Year:** 12000"
        container.add_item(TextDisplay(shop_text))
        container.add_item(Separator())
        options = [SelectOption(label="1 Week", value="7"), SelectOption(label="1 Month", value="28"), SelectOption(label="6 Months", value="180"), SelectOption(label="1 Year", value="365")]
        select = Select(placeholder="Purchase a plan...", options=options)
        select.callback = self.purchase_callback
        row_item = ActionRow()
        row_item.add_item(select)
        container.add_item(row_item)
        self.add_item(container)

    async def purchase_callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author: return
        days = interaction.data['values'][0]
        cost = self.prices[days]
        row = await self.ctx.bot.db.fetchrow("SELECT coins FROM economy WHERE user_id = ?", self.ctx.author.id)
        balance = row['coins'] if row else 0
        if balance < cost: return await interaction.response.send_message("Insufficient coins.", ephemeral=True)

        # 1. Deduct Balance
        await self.ctx.bot.db.execute("UPDATE economy SET coins = coins - ? WHERE user_id = ?", cost, self.ctx.author.id)

        # 2. Add Premium time (extend if active)
        now_ts = datetime.utcnow().timestamp()
        current = await self.ctx.bot.db.fetchrow("SELECT expires_at FROM premium WHERE user_id = ?", self.ctx.author.id)
        start_ts = max(now_ts, current['expires_at']) if current else now_ts
        expires_ts = start_ts + (int(days) * 86400)

        await self.ctx.bot.db.execute("INSERT INTO premium (user_id, expires_at) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET expires_at = ?", self.ctx.author.id, expires_ts, expires_ts)
        await self.ctx.cog.load_premium_cache()

        # 3. Success Message
        await interaction.response.edit_message(view=PremiumUI.create_simple_view("Purchase Success", f"{self.ctx.author.mention}, you purchased **{days} days** of Premium!"), allowed_mentions=AllowedMentions.none())

        # 4. SEND DM
        try:
            await self.ctx.author.send(view=PremiumUI.create_simple_view("Premium Activated", f"Your premium is active until <t:{int(expires_ts)}:F>"))
        except: pass

class Premium(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.user_aliases = defaultdict(dict)
        self.premium_cache = {}

    async def cog_load(self):
        await self.ensure_premium_table()
        await self.load_aliases()
        await self.load_premium_cache()
        self.expiration_task = self.bot.loop.create_task(self.check_expirations())

    async def load_premium_cache(self):
        rows = await self.bot.db.fetch("SELECT * FROM premium WHERE expires_at > ?", datetime.utcnow().timestamp())
        self.premium_cache = { (r['user_id'] if isinstance(r, dict) else r[0]): dict(r) for r in rows }

    async def load_aliases(self):
        rows = await self.bot.db.fetch("SELECT user_id, alias_name, command FROM aliases")
        self.user_aliases.clear()
        for row in rows:
            uid, alias, cmd = (row['user_id'], row['alias_name'], row['command']) if isinstance(row, dict) else row[:3]
            self.user_aliases[uid][alias.lower()] = cmd

    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        if ctx.author.bot: return
        await self.bot.db.execute("INSERT INTO economy (user_id, coins) VALUES (?, 3) ON CONFLICT(user_id) DO UPDATE SET coins = coins + 3", ctx.author.id)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild: return
        uid = message.author.id
        if uid in self.user_aliases:
            prefixes = await self.bot.get_prefix(message)
            if isinstance(prefixes, str): prefixes = [prefixes]
            for prefix in prefixes:
                if message.content.startswith(prefix):
                    content = message.content[len(prefix):].strip()
                    if not content: continue
                    parts = content.split(" ")
                    if parts[0].lower() in self.user_aliases[uid]:
                        message.content = f"{prefix}{self.user_aliases[uid][parts[0].lower()]} {' '.join(parts[1:])}".strip()
                        await self.bot.process_commands(message)
                        return 

    async def ensure_premium_table(self):
        await self.bot.db.execute("CREATE TABLE IF NOT EXISTS premium (user_id INTEGER PRIMARY KEY, expires_at REAL, noprefix BOOLEAN DEFAULT FALSE, recording BOOLEAN DEFAULT FALSE)")
        await self.bot.db.execute("CREATE TABLE IF NOT EXISTS economy (user_id INTEGER PRIMARY KEY, coins INTEGER DEFAULT 0)")
        await self.bot.db.execute("CREATE TABLE IF NOT EXISTS aliases (user_id INTEGER, alias_name TEXT, command TEXT, PRIMARY KEY (user_id, alias_name))")

    async def check_expirations(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                now = datetime.utcnow().timestamp()
                expired = await self.bot.db.fetch("SELECT user_id FROM premium WHERE expires_at <= ?", now)
                for row in expired:
                    uid = row['user_id'] if isinstance(row, dict) else row[0]
                    await self.bot.db.execute("DELETE FROM premium WHERE user_id = ?", uid)
                    await self.bot.db.execute("DELETE FROM aliases WHERE user_id = ?", uid)
                await self.load_premium_cache()
                await asyncio.sleep(3600)
            except: await asyncio.sleep(600)

    # --- ECONOMY COMMANDS ---
    @commands.command(name="balance", aliases=["bal", "coins"])
    async def balance(self, ctx, user: discord.User = None):
        user = user or ctx.author
        row = await self.bot.db.fetchrow("SELECT coins FROM economy WHERE user_id = ?", user.id)
        coins = row['coins'] if row else 0
        await ctx.send(view=PremiumUI.create_simple_view("Balance", f"**User:** {user.mention}\n**Balance:** `{coins}` coins"), allowed_mentions=AllowedMentions.none())

    @commands.command(name="buy")
    async def buy_premium_shop(self, ctx):
        view = PremiumBuyView(ctx)
        await view.build()
        await ctx.send(view=view)

    # --- PREMIUM COMMANDS ---
    @commands.group(name="premium", invoke_without_command=True)
    async def premium(self, ctx): await ctx.send_help(ctx.command)

    @premium.command(name="add")
    async def premium_add(self, ctx, user: Union[discord.Member, discord.User]):
        if ctx.author.id not in config.owners: return
        view = PremiumDurationSelect(ctx, user); await view.build()
        await ctx.send(view=view, allowed_mentions=AllowedMentions.none())

    @premium.command(name="remove")
    async def premium_remove(self, ctx, user: Union[discord.Member, discord.User]):
        if ctx.author.id not in config.owners: return
        await self.bot.db.execute("DELETE FROM premium WHERE user_id = ?", user.id); await self.load_premium_cache()
        await ctx.send(view=PremiumUI.create_simple_view("Premium Removed", f"Removed premium from {user.mention}"), allowed_mentions=AllowedMentions.none())

    @premium.command(name="list")
    async def premium_list(self, ctx):
        if ctx.author.id not in config.owners: return
        if not self.premium_cache: return await ctx.send(view=PremiumUI.create_simple_view("Premium Users", "No active users."))
        fmt = [f"• <@{u}> | <t:{int(d['expires_at'])}:D>" for u, d in self.premium_cache.items()]
        view = PremiumListPagination(ctx, fmt); await view.build()
        await ctx.send(view=view, allowed_mentions=AllowedMentions.none())

    # --- ALIAS COMMANDS ---
    @commands.group(name="alias", invoke_without_command=True)
    async def alias(self, ctx):
        if ctx.author.id not in self.premium_cache: return await ctx.send(view=PremiumUI.create_simple_view("Premium Only", "This feature is restricted to premium users."))
        await ctx.send(view=PremiumUI.create_simple_view("Alias Help", "`alias add <name> <cmd>`\n`alias remove <name>`\n`alias list`"))

    @alias.command(name="add")
    async def alias_add(self, ctx, name, *, cmd):
        if ctx.author.id not in self.premium_cache: return
        await self.bot.db.execute("INSERT OR REPLACE INTO aliases VALUES (?, ?, ?)", ctx.author.id, name.lower(), cmd)
        await self.load_aliases(); await ctx.send(view=PremiumUI.create_simple_view("Alias Added", f"Alias `{name}` successfully mapped to `{cmd}`."))

    @alias.command(name="remove")
    async def alias_remove(self, ctx, name):
        if ctx.author.id not in self.premium_cache: return
        await self.bot.db.execute("DELETE FROM aliases WHERE user_id = ? AND alias_name = ?", ctx.author.id, name.lower())
        await self.load_aliases(); await ctx.send(view=PremiumUI.create_simple_view("Alias Removed", f"Alias `{name}` removed."))

    @alias.command(name="list")
    async def alias_list(self, ctx):
        if ctx.author.id not in self.premium_cache: return
        items = self.user_aliases.get(ctx.author.id, {})
        if not items: return await ctx.send(view=PremiumUI.create_simple_view("Aliases", "No aliases set."))
        await ctx.send(view=PremiumUI.create_simple_view("Your Aliases", "\n".join([f"`{k}` -> `{v}`" for k, v in items.items()])))

    # --- BOT PROFILE ---
    @commands.group(name="botprofile", aliases=["bp"], invoke_without_command=True)
    async def botprofile(self, ctx):
        if ctx.author.id not in self.premium_cache: return await ctx.send(view=PremiumUI.create_simple_view("Premium Only", "This feature is restricted to premium users."))
        await ctx.send(view=PremiumUI.create_simple_view("BP Help", "`bp name <text>`\n`bp avatar <url>`\n`bp banner <url>`\n`bp bio <text>`"))

    @botprofile.command(name="name")
    async def bp_name(self, ctx, *, name):
        if ctx.author.id not in self.premium_cache: return
        try: await ctx.guild.me.edit(nick=name); await ctx.send(view=PremiumUI.create_simple_view("BP Updated", f"Nickname set to `{name}`."))
        except: await ctx.send(view=PremiumUI.create_simple_view("Error", "Missing Permissions."))

    @botprofile.command(name="avatar")
    async def bp_avatar(self, ctx, url=None):
        if ctx.author.id not in self.premium_cache: return
        img = await get_image_bytes(ctx, url)
        if not img: return await ctx.send(view=PremiumUI.create_simple_view("Error", "Provide an image."))
        try: await self.bot.http.request(discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me"), json={"avatar": to_base64_image(img)}); await ctx.send(view=PremiumUI.create_simple_view("BP Updated", "Avatar updated."))
        except: await ctx.send(view=PremiumUI.create_simple_view("Error", "Failed to update."))

    @botprofile.command(name="banner")
    async def bp_banner(self, ctx, url=None):
        if ctx.author.id not in self.premium_cache: return
        img = await get_image_bytes(ctx, url)
        if not img: return await ctx.send(view=PremiumUI.create_simple_view("Error", "Provide an image."))
        try: await self.bot.http.request(discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me"), json={"banner": to_base64_image(img)}); await ctx.send(view=PremiumUI.create_simple_view("BP Updated", "Banner updated."))
        except: await ctx.send(view=PremiumUI.create_simple_view("Error", "Failed to update."))

    @botprofile.command(name="bio")
    async def bp_bio(self, ctx, *, bio):
        if ctx.author.id not in self.premium_cache: return
        try: await self.bot.http.request(discord.http.Route("PATCH", f"/guilds/{ctx.guild.id}/members/@me"), json={"bio": bio}); await ctx.send(view=PremiumUI.create_simple_view("BP Updated", "Bio updated."))
        except: await ctx.send(view=PremiumUI.create_simple_view("Error", "Failed to update."))

    # --- NO PREFIX ---
    @commands.group(name="noprefix", invoke_without_command=True)
    async def noprefix(self, ctx):
        if ctx.author.id not in self.premium_cache: return await ctx.send(view=PremiumUI.create_simple_view("Premium Only", "This feature is restricted to premium users."))
        s = "Enabled" if self.premium_cache[ctx.author.id].get('noprefix') else "Disabled"
        await ctx.send(view=PremiumUI.create_simple_view("NoPrefix", f"Current Status: **{s}**"), allowed_mentions=AllowedMentions.none())

    @noprefix.command(name="enable")
    async def nop_enable(self, ctx):
        if ctx.author.id not in self.premium_cache: return
        await self.bot.db.execute("UPDATE premium SET noprefix = ? WHERE user_id = ?", True, ctx.author.id)
        await self.load_premium_cache(); await ctx.send(view=PremiumUI.create_simple_view("NoPrefix", "NoPrefix enabled."), allowed_mentions=AllowedMentions.none())

    @noprefix.command(name="disable")
    async def nop_disable(self, ctx):
        if ctx.author.id not in self.premium_cache: return
        await self.bot.db.execute("UPDATE premium SET noprefix = ? WHERE user_id = ?", False, ctx.author.id)
        await self.load_premium_cache(); await ctx.send(view=PremiumUI.create_simple_view("NoPrefix", "NoPrefix disabled."), allowed_mentions=AllowedMentions.none())

async def setup(bot): await bot.add_cog(Premium(bot))
