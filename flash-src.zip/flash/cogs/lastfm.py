import discord
from discord.ext import commands
from discord import ButtonStyle, AllowedMentions, SelectOption
from discord.ui import LayoutView, TextDisplay, Container, ActionRow, Separator, Button, Select
import aiohttp
import asyncio
import os
from datetime import datetime
from urllib.parse import quote

# Configuration - Add your API key here directly
LASTFM_API_KEY = "05ebef21b2a008c27f9c5a4fbcc14348"
LASTFM_BASE_URL = "http://ws.audioscrobbler.com/2.0/"

class LastFMUI:
    @staticmethod
    def create_simple_view(title: str, content: str, color: int = 0xFFFFFF):
        """Matches the layout style of premium.py"""
        view = LayoutView()
        container = Container(accent_color=color)
        container.add_item(TextDisplay(f"### {title}\n{content}"))
        view.add_item(container)
        return view

class LastFM(commands.Cog):
    """Last.fm music tracking with Premium UI layout"""
    
    def __init__(self, bot):
        self.bot = bot
        self.session = None

    async def cog_load(self):
        """Initialize tables in database.db"""
        await self.bot.db.execute("""
            CREATE TABLE IF NOT EXISTS lastfm_users (
                user_id INTEGER PRIMARY KEY,
                username TEXT NOT NULL,
                scrobbles INTEGER DEFAULT 0,
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

    async def get_session(self):
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session

    async def fetch(self, method, **params):
        """Internal helper to fetch data from Last.fm API"""
        if not LASTFM_API_KEY or LASTFM_API_KEY == "YOUR_LASTFM_API_KEY":
            return {"error": "API Key not configured."}
        
        session = await self.get_session()
        params.update({
            'method': method,
            'api_key': LASTFM_API_KEY,
            'format': 'json'
        })
        
        try:
            async with session.get(LASTFM_BASE_URL, params=params, timeout=10) as resp:
                data = await resp.json()
                if 'error' in data:
                    return None
                return data
        except:
            return None

    @commands.group(name="lastfm", aliases=['fm', 'lfm'], invoke_without_command=True)
    async def lastfm(self, ctx):
        """Main help menu redesigned"""
        content = (
            "• `login <username>` — Link your Last.fm account\n"
            "• `profile [@user]` — View music statistics\n"
            "• `np [@user]` — See currently playing track\n"
            "• `topartists [period]` — Your most played artists\n"
            "• `toptracks [period]` — Your most played tracks\n"
            "• `compat <@user>` — Compare music taste\n"
            "• `scrobbles` — View total play count\n"
            "• `logout` — Unlink your account"
        )
        view = LastFMUI.create_simple_view("Last.fm Commands", content)
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="login", aliases=['set'])
    async def lastfm_login(self, ctx, username: str):
        """Link Discord to Last.fm"""
        data = await self.fetch('user.getInfo', user=username)
        if not data:
            return await ctx.reply(view=LastFMUI.create_simple_view("Error", "Last.fm user not found. Check the spelling."), mention_author=False)

        user_info = data['user']
        playcount = int(user_info.get('playcount', 0))
        
        await self.bot.db.execute(
            "INSERT INTO lastfm_users (user_id, username, scrobbles) VALUES (?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET username = ?, scrobbles = ?",
            ctx.author.id, username, playcount, username, playcount
        )
        
        content = (
            f"Successfully linked **{ctx.author.name}** to **{username}**\n"
            f"Total Scrobbles: `{playcount:,}`\n"
            f"Country: `{user_info.get('country', 'Not set')}`"
        )
        await ctx.reply(view=LastFMUI.create_simple_view("Account Linked", content), mention_author=False)

    @lastfm.command(name="profile", aliases=['p'])
    async def lastfm_profile(self, ctx, user: discord.Member = None):
        """View music profile information"""
        target = user or ctx.author
        row = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", target.id)
        
        if not row:
            return await ctx.reply(view=LastFMUI.create_simple_view("Error", f"{target.mention} has not linked a Last.fm account."), mention_author=False)

        data = await self.fetch('user.getInfo', user=row['username'])
        if not data:
            return await ctx.reply(view=LastFMUI.create_simple_view("Error", "Could not retrieve Last.fm data."), mention_author=False)

        u = data['user']
        content = (
            f"**Username:** {u['name']}\n"
            f"**Real Name:** {u.get('realname') or 'N/A'}\n"
            f"**Scrobbles:** `{int(u['playcount']):,}`\n"
            f"**Country:** {u.get('country', 'Hidden')}\n"
            f"**Registered:** <t:{u['registered']['#text']}:D>"
        )
        view = LastFMUI.create_simple_view(f"{target.name}'s Music Profile", content)
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="np", aliases=['nowplaying'])
    async def lastfm_np(self, ctx, user: discord.Member = None):
        """Show what is currently playing"""
        target = user or ctx.author
        row = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", target.id)
        if not row:
            return await ctx.reply("Account not linked.")

        data = await self.fetch('user.getRecentTracks', user=row['username'], limit=1)
        if not data or 'track' not in data['recenttracks'] or not data['recenttracks']['track']:
            return await ctx.reply("No recent tracks found.")

        track = data['recenttracks']['track'][0]
        artist = track['artist']['#text']
        track_name = track['name']
        album = track['album']['#text'] or "No Album"
        
        # Check if currently playing
        is_playing = "@attr" in track and track['@attr'].get('nowplaying') == 'true'
        status = "Currently Listening" if is_playing else "Last Played"
        
        content = (
            f"**Artist:** {artist}\n"
            f"**Track:** {track_name}\n"
            f"**Album:** {album}"
        )
        
        view = LastFMUI.create_simple_view(f"{status} — {target.name}", content)
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="topartists", aliases=['ta'])
    async def lastfm_topartists(self, ctx, period: str = "overall"):
        """Show top artists for a specific period"""
        row = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", ctx.author.id)
        if not row: return await ctx.reply("Link your account first.")

        valid = {"7day": "Weekly", "1month": "Monthly", "3month": "3 Months", "6month": "6 Months", "12month": "Yearly", "overall": "All Time"}
        period = period.lower() if period.lower() in valid else "overall"

        data = await self.fetch('user.getTopArtists', user=row['username'], period=period, limit=10)
        if not data: return await ctx.reply("No data found.")

        artists = data.get('topartists', {}).get('artist', [])
        formatted = "\n".join([f"`{i+1}.` **{a['name']}** — `{a['playcount']}` plays" for i, a in enumerate(artists)])
        
        view = LastFMUI.create_simple_view(f"Top Artists ({valid[period]})", formatted or "No data available.")
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="toptracks", aliases=['tt'])
    async def lastfm_toptracks(self, ctx, period: str = "overall"):
        """Show top tracks for a specific period"""
        row = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", ctx.author.id)
        if not row: return await ctx.reply("Link your account first.")

        valid = {"7day": "Weekly", "1month": "Monthly", "overall": "All Time"}
        period = period.lower() if period.lower() in valid else "overall"

        data = await self.fetch('user.getTopTracks', user=row['username'], period=period, limit=10)
        if not data: return await ctx.reply("No data found.")

        tracks = data.get('toptracks', {}).get('track', [])
        formatted = "\n".join([f"`{i+1}.` **{t['name']}** by *{t['artist']['name']}* — `{t['playcount']}`" for i, t in enumerate(tracks)])
        
        view = LastFMUI.create_simple_view(f"Top Tracks ({valid[period]})", formatted or "No data available.")
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="scrobbles", aliases=['s'])
    async def lastfm_scrobbles(self, ctx, user: discord.Member = None):
        """Quick check for total scrobbles"""
        target = user or ctx.author
        row = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", target.id)
        if not row: return await ctx.reply("Account not linked.")

        data = await self.fetch('user.getInfo', user=row['username'])
        if not data: return await ctx.reply("API Error.")

        count = int(data['user']['playcount'])
        await ctx.reply(view=LastFMUI.create_simple_view("Scrobbles", f"**{target.name}** has **{count:,}** total scrobbles."), mention_author=False)

    @lastfm.command(name="compat", aliases=['compare'])
    async def lastfm_compat(self, ctx, target: discord.Member):
        """Compare music taste with another user"""
        u1 = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", ctx.author.id)
        u2 = await self.bot.db.fetchrow("SELECT username FROM lastfm_users WHERE user_id = ?", target.id)
        
        if not u1 or not u2:
            return await ctx.reply(view=LastFMUI.create_simple_view("Error", "Both users must have Last.fm accounts linked."), mention_author=False)

        data = await self.fetch('tasteometer.compare', type1='user', value1=u1['username'], type2='user', value2=u2['username'])
        
        if not data:
            return await ctx.reply("Comparison failed.")
        
        res = data['comparison']['result']
        score = float(res['score']) * 100
        common = res.get('artists', {}).get('artist', [])
        common_list = ", ".join([a['name'] for a in common[:5]]) if common else "None"

        # Determine emoji based on score
        emoji = "💔"
        if score > 80: emoji = "❤️"
        elif score > 50: emoji = "💛"
        elif score > 20: emoji = "🧡"

        content = (
            f"{emoji} **Compatibility Score:** `{score:.1f}%`\n"
            f"**Common Artists:** {common_list}\n\n"
            f"**Users:** {ctx.author.mention} & {target.mention}"
        )
        
        view = LastFMUI.create_simple_view("Music Compatibility", content)
        await ctx.reply(view=view, mention_author=False)

    @lastfm.command(name="logout", aliases=['unlink'])
    async def lastfm_logout(self, ctx):
        """Remove Last.fm link"""
        await self.bot.db.execute("DELETE FROM lastfm_users WHERE user_id = ?", ctx.author.id)
        await ctx.reply(view=LastFMUI.create_simple_view("Success", "Your Last.fm account has been unlinked."), mention_author=False)

    async def cog_unload(self):
        if self.session:
            await self.session.close()

async def setup(bot):
    await bot.add_cog(LastFM(bot))