CREATE TABLE IF NOT EXISTS prefixes (
    guild_id bigint NOT NULL UNIQUE,
    prefix text
);

CREATE TABLE IF NOT EXISTS profile (
    user_id bigint NOT NULL PRIMARY KEY,
    description text,
    socials text,
    friends text
);

CREATE TABLE IF NOT EXISTS blacklist (
    object_id BIGINT NOT NULL,
    object_type text NOT NULL,
    PRIMARY KEY (object_id, object_type)
);

CREATE TABLE IF NOT EXISTS afk (
    user_id BIGINT NOT NULL PRIMARY KEY,
    reason TEXT
);

CREATE TABLE IF NOT EXISTS antinuke_settings (
    guild_id BIGINT PRIMARY KEY,
    enabled BOOLEAN DEFAULT FALSE,
    action TEXT DEFAULT 'kick',
    threshold INTEGER DEFAULT 3
);

CREATE TABLE IF NOT EXISTS antinuke_whitelist (
    guild_id BIGINT,
    user_id BIGINT,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS antinuke_admins (
    guild_id BIGINT,
    user_id BIGINT,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS premium (
    user_id BIGINT PRIMARY KEY,
    noprefix BOOLEAN DEFAULT FALSE,
    emergency BOOLEAN DEFAULT FALSE,
    nightmode BOOLEAN DEFAULT FALSE
);
