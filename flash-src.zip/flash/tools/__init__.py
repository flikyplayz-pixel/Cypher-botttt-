import asyncio
import functools
import time
from typing import Any, Callable, Dict, Tuple

def ratelimit(bucket_name: str, rate: int, per: float):
    """
    Simple ratelimit decorator.
    bucket_name: A string template for the bucket, e.g. "prefix_message:{message.guild.id}"
    rate: Number of allowed calls
    per: Period in seconds
    """
    buckets: Dict[str, Tuple[int, float]] = {}

    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Very basic implementation for now
            # In a real bot, you'd parse bucket_name template from args/kwargs
            # For simplicity, we'll just use the bucket_name as is or a basic hash
            now = time.time()
            if bucket_name not in buckets:
                buckets[bucket_name] = (rate - 1, now)
                return await func(*args, **kwargs)
            
            count, last_time = buckets[bucket_name]
            if now - last_time > per:
                buckets[bucket_name] = (rate - 1, now)
                return await func(*args, **kwargs)
            
            if count > 0:
                buckets[bucket_name] = (count - 1, last_time)
                return await func(*args, **kwargs)
            
            # Rate limited
            return None
        return wrapper
    return decorator

def lock(name: str):
    """
    Simple lock decorator.
    """
    _locks: Dict[str, asyncio.Lock] = {}

    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if name not in _locks:
                _locks[name] = asyncio.Lock()
            async with _locks[name]:
                return await func(*args, **kwargs)
        return wrapper
    return decorator
