import os
import subprocess
import sys
from typing import Optional, List, Dict
from playwright.async_api import Page, BrowserContext, async_playwright
from dataclasses import dataclass
from uuid import uuid4 as tuuid 
from discord import File
from io import BytesIO
from asyncio import ensure_future, sleep
from playwright_stealth import stealth

# Force Playwright to use a local folder instead of /home/container/.cache
# This is crucial for hosting that restricts system folders
BROWSER_PATH = os.path.join(os.getcwd(), "pw-browsers")
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = BROWSER_PATH

@dataclass
class BrowserPage:
    page: Page
    key: str
    busy: bool

class Session:
    def __init__(self, headless: bool = True, proxy: Optional[Dict[str, str]] = None):
        self.proxies: Optional[List[Dict[str, str]]] = [proxy] if proxy else None
        self.headless: bool = headless
        self.pages: List[BrowserPage] = []
        self._playwright = None
        self.browser = None
        self.context = None

    async def install_browser(self):
        """Forces automatic download of Chromium into the bot folder."""
        print(f"--- BROWSER NOT FOUND. DOWNLOADING TO {BROWSER_PATH} ---")
        try:
            # This runs the install command programmatically
            subprocess.run([
                sys.executable, "-m", "playwright", "install", "chromium"
            ], check=True)
            print("--- CHROMIUM DOWNLOADED SUCCESSFULLY ---")
        except Exception as e:
            print(f"--- AUTOMATIC INSTALL FAILED: {e} ---")
            print("Your host may be blocking downloads.")

    async def launch(self):
        if self._playwright: return
        self._playwright = await async_playwright().start()
        
        proxy_settings = None
        if self.proxies and self.proxies[0]:
            proxy_settings = self.proxies[0]

        try:
            # Try to launch from the local folder
            self.browser = await self._playwright.chromium.launch(
                args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
                proxy=proxy_settings,
                headless=self.headless
            )
        except Exception as e:
            if "Executable doesn't exist" in str(e) or "not found" in str(e).lower():
                await self.install_browser()
                # Try launching again after installation
                self.browser = await self._playwright.chromium.launch(
                    args=["--no-sandbox", "--disable-setuid-sandbox"],
                    proxy=proxy_settings,
                    headless=self.headless
                )
            else:
                raise e

        self.context = await self.browser.new_context(
            user_agent="Mozilla/5.0 (X11; Linux x86_64; rv:104.0) Gecko/20100101 Firefox/104.0"
        )

    async def get_page(self) -> BrowserPage:
        if not self.browser:
            await self.launch()

        for bp in self.pages:
            if not bp.busy:
                bp.busy = True
                ensure_future(self.update_page(bp.key, True))
                return bp

        page = await self.context.new_page()
        await stealth(page)
        
        key = str(tuuid())
        browser_page = BrowserPage(page=page, key=key, busy=True)
        self.pages.append(browser_page)
        
        ensure_future(self.update_page(key, True))
        return browser_page

    async def update_page(self, key: str, later: bool = False):
        if later:
            await sleep(20)
        for bp in self.pages:
            if bp.key == key:
                bp.busy = False
                return True
        return False
    
    async def screenshot(self, url: str) -> File:
        browser_page = await self.get_page()
        page = browser_page.page
        try:
            await page.goto(url, wait_until="networkidle", timeout=60000)
            img = await page.screenshot()
            return File(fp=BytesIO(img), filename="screenshot.png")
        finally:
            await self.update_page(browser_page.key, False)