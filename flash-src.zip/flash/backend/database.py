from __future__ import annotations

import loguru
import aiosqlite
import ujson
from typing import Any, Optional, Union, Iterable, Sequence, Dict

log: loguru.logger = loguru.logger

class Record(dict):
    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)

class Database:
    def __init__(self, db_path: str = "database.db"):
        self.db_path: str = db_path
        self._connection: Optional[aiosqlite.Connection] = None

    async def connect(self) -> aiosqlite.Connection:
        self._connection = await aiosqlite.connect(self.db_path)
        log.info(f"Initialized database connection to {self.db_path}")
        return self._connection

    def dict_factory(self, cursor, row):
        d = Record()
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d

    async def close(self) -> None:
        if self._connection:
            await self._connection.close()
            log.info(f"Closed database connection to {self.db_path}")

    async def fetch(self, sql: str, *args):
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = self.dict_factory
            async with db.execute(sql, args) as cursor:
                return await cursor.fetchall()
            
    async def fetchiter(self, sql: str, *args):
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = self.dict_factory
            async with db.execute(sql, args) as cursor:
                async for row in cursor:
                    yield row

    async def fetchrow(self, sql: str, *args):
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = self.dict_factory
            async with db.execute(sql, args) as cursor:
                return await cursor.fetchone()

    async def fetchval(self, sql: str, *args):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(sql, args) as cursor:
                row = await cursor.fetchone()
                return row[0] if row else None

    async def execute(self, sql: str, *args) -> Any:
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(sql, args)
            await db.commit()
            return None

    async def executemany(self, sql: str, args: Iterable[Sequence]) -> Any:
        async with aiosqlite.connect(self.db_path) as db:
            await db.executemany(sql, args)
            await db.commit()
            return None
