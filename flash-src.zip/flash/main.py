import os
import sys
import traceback
import asyncio
import discord
import logging
from pathlib import Path
from sys import stdout
from typing import Optional, List
from discord.ext import commands
from discord.ext.commands import Bot, Context, when_mentioned_or, CommandError, MissingPermissions, cooldown, BucketType
from discord import Embed, Message, Guild, Intents, User
from discord.ui import LayoutView, TextDisplay, Container
from loguru import logger

# ============ SILENCE INTERNAL COMMAND ERRORS ============
logging.getLogger('discord.ext.commands').setLevel(logging.CRITICAL)
logging.getLogger('discord').setLevel(logging.ERROR)
# ============ END LOG SILENCING ============

# Project imports
import config
from tools import ratelimit
from backend.database import Database
# REMOVED browser import to stop chromium downloads

# ============ MOBILE STATUS PATCH ============
async def patched_identify(self):
    payload = {
        'op': self.IDENTIFY,
        'd': {
            'token': self.token,
            'properties': {
                '$os': 'android',
                '$browser': 'Discord Android',
                '$device': 'Discord Android',
                '$referrer': '',
                '$referring_domain': ''
            },
            'compress': True,
            'large_threshold': 250,
            'v': 3
        }
    }
    if self.shard_id is not None:
        payload['d']['shard'] = [self.shard_id, self.shard_count]

    state = self._connection
    if hasattr(state, 'intents'):
        payload['d']['intents'] = state.intents.value
    elif hasattr(self, '_intents'):
        payload['d']['intents'] = self._intents.value

    presence = getattr(state, '_presence', getattr(state, '_p_presence', None))
    if presence:
        payload['d']['presence'] = presence

    if hasattr(self, 'call_hooks'):
        try:
            await self.call_hooks('before_identify', self.shard_id, initial=True)
        except: pass
    
    await self.send_as_json(payload)
    logger.info(f"Shard {self.shard_id} identified (Mobile + Status).")

discord.gateway.DiscordWebSocket.identify = patched_identify
# ============ END MOBILE PATCH ============

os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"
os.environ["JISHAKU_RETAIN"] = "True"

# Custom UI view for loading messages
class LoadingView(LayoutView):
    def __init__(self):
        super().__init__()
        self.container = Container(accent_color=discord.Color.from_str("#FFFFFF"))
    
    def finalize(self):
        self.add_item(self.container)

# Context helper methods
async def success(self: Context, message: str) -> Message:
    """Send a success message using UI"""
    view = LoadingView()
    view.container.add_item(TextDisplay(f"✅ {message}"))
    view.finalize()
    return await self.send(view=view)

async def fail(self: Context, message: str) -> Message:
    """Send an error message using UI"""
    view = LoadingView()
    view.container.add_item(TextDisplay(f"❌ {message}"))
    view.finalize()
    return await self.send(view=view)

Context.success = success
Context.fail = fail

class Antinuke(Bot):
    def __init__(self, **kwargs):
        self.color = 0x2D2D2C
        self.config = config
        self.db = Database(self.config.uri)
        self.session = None
        self.lavalink = None  # ADDED: Lavalink attribute
        
        intents = Intents.all()
        
        # Simple initial activity - will update in on_ready
        activity = discord.Activity(
            type=discord.ActivityType.custom, 
            name="custom", 
            state="Starting up..."
        )
        
        super().__init__(
            command_prefix=self.get_prefix,
            intents=intents,
            help_command=None,
            activity=activity,
            status=discord.Status.online,
            owner_ids=[1463384068702998710],
            **kwargs
        )
        
        self.before_invoke = self.add_cooldown_to_commands
    
    async def add_cooldown_to_commands(self, ctx):
        if await self.is_owner(ctx.author):
            return
        if not ctx.command:
            return
        bucket = commands.CooldownMapping.from_cooldown(1, 5.0, commands.BucketType.user).get_bucket(ctx.message)
        retry_after = bucket.update_rate_limit()
        if retry_after:
            raise commands.CommandOnCooldown(bucket, retry_after, commands.BucketType.user)

    async def is_owner(self, user: User):
        if user.id in self.owner_ids:
            return True
        return await super().is_owner(user)

    async def get_guild_prefixes(self, guild_id: int) -> List[str]:
        """Get all prefixes for a guild from database."""
        if not guild_id:
            return [","]  # Default prefix
        
        try:
            rows = await self.db.fetch(
                "SELECT prefix FROM prefixes WHERE guild_id = ?",
                guild_id
            )
            db_prefixes = [row.prefix for row in rows]
            if db_prefixes:
                return db_prefixes
            else:
                return [","]  # Default prefix if none set
        except:
            return [","]  # Fallback to default prefix

    async def get_prefix(self, message: Message):
        """Get prefix for a message."""
        if not message.guild:
            # For DMs, use default prefix or mention
            prefixes = [","]
            if message.author:
                premium = await self.db.fetchrow("SELECT noprefix FROM premium WHERE user_id = ?", message.author.id)
                if premium and premium.noprefix:
                    prefixes.append("")  # Allow no-prefix for premium users in DMs
            return when_mentioned_or(*prefixes)(self, message)
        
        # For guild messages
        guild_prefixes = await self.get_guild_prefixes(message.guild.id)
        
        # Check for premium user no-prefix
        if message.author:
            premium = await self.db.fetchrow("SELECT noprefix FROM premium WHERE user_id = ?", message.author.id)
            if premium and premium.noprefix:
                guild_prefixes.append("")  # Add empty string for no-prefix mode
        
        # Also add mentions as valid prefixes
        return when_mentioned_or(*guild_prefixes)(self, message)

    async def on_guild_join(self, guild: Guild) -> None:
        try:
            if hasattr(self.config, 'CHANNEL') and self.config.CHANNEL:
                channel = self.get_channel(int(self.config.CHANNEL))
                if channel and channel.permissions_for(guild.me).send_messages:
                    view = LoadingView()
                    view.container.add_item(TextDisplay(
                        f"✅ **Joined {guild.name}**\n"
                        f"👥 **Members:** {len(guild.members)}\n"
                        f"👑 **Owner:** {str(guild.owner)}\n"
                        f"🆔 **ID:** {guild.id}"
                    ))
                    view.finalize()
                    await channel.send(view=view)
                    logger.info(f"Joined guild: {guild.name} (ID: {guild.id})")
        except Exception as e:
            logger.error(f"Error in on_guild_join: {e}")

    async def process_commands(self, message: Message):
        if not message.guild or message.author.bot:
            return
        check = await self.db.fetchrow("SELECT * FROM blacklist WHERE (object_id = ? AND object_type = ?) OR (object_id = ? AND object_type = ?)", message.author.id, "user_id", message.guild.id, "guild_id")
        if check or not self.is_ready():
            return
        return await super().process_commands(message)

    async def on_message(self, message: Message):
        # Ignore bot messages (including our own)
        if message.author.bot:
            return
        
        # Ignore messages without guild context
        if not message.guild:
            return
        
        try:
            # Check if message is a reply to a bot message
            if message.reference:
                try:
                    referenced_msg = await message.channel.fetch_message(message.reference.message_id)
                    if referenced_msg.author.bot:
                        # Don't process commands in replies to bot messages
                        return
                except:
                    pass
            
            # Check if message contains @everyone or @here mentions
            if "@everyone" in message.content or "@here" in message.content:
                return
            
            # Get guild prefixes
            prefixes = await self.get_guild_prefixes(message.guild.id)
            
            # Check if message starts with any prefix
            starts_with_prefix = False
            content = message.content
            
            # Check for direct mention (but not @everyone/@here)
            # Only process if the bot is specifically mentioned (not in @everyone/@here)
            mentions_bot = False
            for mention in message.mentions:
                if mention.id == self.user.id:
                    # Check if this is part of @everyone or @here
                    if not ("@everyone" in content or "@here" in content):
                        mentions_bot = True
                    break
            
            if mentions_bot:
                starts_with_prefix = True
            else:
                for prefix in prefixes:
                    if prefix and content.startswith(prefix):
                        starts_with_prefix = True
                        break
            
            # Check for premium user no-prefix
            premium = await self.db.fetchrow("SELECT noprefix FROM premium WHERE user_id = ?", message.author.id)
            if premium and premium.noprefix:
                # For premium users with no-prefix mode, check if message starts with a command
                if not starts_with_prefix:
                    # Check if first word is a command
                    first_word = content.split()[0] if content.split() else ""
                    command = self.get_command(first_word)
                    if command:
                        # Dispatch no-prefix command event
                        self.dispatch("noprefix_command", message, first_word)
                        # Process as command
                        starts_with_prefix = True
            
            # Handle mention-only messages (only if bot is specifically mentioned)
            if mentions_bot and len(message.content.split()) == 1:
                @ratelimit("prefix_message:{message.guild.id}", 1, 5)
                async def prefix_message(message: Message):
                    current_prefixes = await self.get_guild_prefixes(message.guild.id)
                    if len(current_prefixes) == 1:
                        view = LoadingView()
                        view.container.add_item(TextDisplay(f"My current prefix is `{current_prefixes[0]}`"))
                        view.finalize()
                        return await message.channel.send(view=view)
                    else:
                        prefix_list = ", ".join([f"`{p}`" for p in current_prefixes])
                        view = LoadingView()
                        view.container.add_item(TextDisplay(f"My current prefixes are: {prefix_list}"))
                        view.finalize()
                        return await message.channel.send(view=view)
                return await prefix_message(message)
            
            # Process commands if message starts with prefix
            if starts_with_prefix:
                await self.process_commands(message)
                
        except Exception as e:
            logger.error(f"Error in on_message: {e}")

    async def setup_hook(self):
        import aiohttp
        import lavalink  # ADDED: Import lavalink
        
        # Fix for folders: Ensure main directory is in path
        sys.path.insert(0, os.getcwd())
        
        self.session = aiohttp.ClientSession()
        await self.db.connect()
        
        # Initialize database schema
        if os.path.exists("flash/install/schema.sql"):
            with open("flash/install/schema.sql", "r") as file:
                tables = file.read().split(";")
            for table in tables:
                try:
                    if table.strip(): await self.db.execute(f"{table};")
                except: pass
        
        # Create prefixes table if it doesn't exist
        await self.db.execute("""
            CREATE TABLE IF NOT EXISTS prefixes (
                guild_id INTEGER,
                prefix TEXT,
                PRIMARY KEY (guild_id, prefix)
            )
        """)
        
        # LOAD COGS FIX: Using roxie.cogs dot notation
        cogs_path = Path("flash/cogs")
        if cogs_path.exists():
            loaded_count = 0
            for c in cogs_path.glob("*.py"):
                if c.name.startswith("__"): continue
                try:
                    # Using the full path from the root
                    cog_name = c.stem
                    await self.load_extension(f"flash.cogs.{cog_name}")
                    
                    # Create loading message with custom UI
                    view = LoadingView()
                    view.container.add_item(TextDisplay(
                        f"```ansi\n[2;34m[{discord.utils.utcnow().strftime('%H:%M:%S')}][0m Loaded {cog_name}\n```"
                    ))
                    view.finalize()
                    
                    # Send to console (simulate UI)
                    print(f"\033[94m[{discord.utils.utcnow().strftime('%H:%M:%S')}]\033[0m Loaded \033[97m{cog_name}\033[0m")
                    
                    loaded_count += 1
                except Exception as e:
                    logger.error(f"Failed to load {c.stem}: {e}")
                    traceback.print_exc()
            
            # Final summary
            print(f"\n\033[92m✓ Loaded {loaded_count} extensions from flash/cogs.\033[0m")
        
        try: 
            await self.load_extension("jishaku")
            print(f"\033[94m[{discord.utils.utcnow().strftime('%H:%M:%S')}]\033[0m Loaded \033[97mjishaku\033[0m")
        except Exception as e: 
            print(f"\033[91mFailed to load jishaku: {e}\033[0m")
            pass

    @ratelimit("rl:error_message:{ctx.guild.id}", 1, 5)
    async def error_message(self, ctx: Context, message: str) -> Optional[Message]:
        return await ctx.fail(message)

    async def on_command_error(self, ctx: Context, error: Exception):
        if isinstance(error, commands.CommandNotFound): return
        elif isinstance(error, commands.CommandOnCooldown):
            return await self.error_message(ctx, f"⏰ This command is on cooldown. Try again in **{error.retry_after:.1f}s**")
        elif isinstance(error, commands.MissingRequiredArgument):
            return await self.error_message(ctx, f"Please include a **{error.param.name.title()}**")
        elif isinstance(error, commands.MissingPermissions):
            return await self.error_message(ctx, f"You're **missing** the `{', '.join(error.missing_permissions)}` permission")
        
        tb = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        logger.error(f"Error in {ctx.command}: {tb}")

    async def on_ready(self):
        # Initialize lavalink after bot is ready
        try:
            import lavalink
            self.lavalink = lavalink.Client(self.user.id)
            self.lavalink.add_node(
                host='lavalinkv4.serenetia.com',  # Change this if your lavalink server is elsewhere
                port=80,
                password='https://dsc.gg/ajidevserver',  # Default lavalink password
                region='us'
            )
            print(f"\033[94m[{discord.utils.utcnow().strftime('%H:%M:%S')}]\033[0m Initialized \033[97mlavalink\033[0m")
        except ImportError:
            print("\033[93mWarning: lavalink not installed. Music features will be disabled.\033[0m")
            self.lavalink = None
        except Exception as e:
            print(f"\033[91mFailed to initialize lavalink: {e}\033[0m")
            self.lavalink = None
        
        # FIXED: Use self.users and self.guilds instead of self.bot.users/self.bot.guilds
        activity = discord.Activity(
            type=discord.ActivityType.custom, 
            name="custom", 
            state=f"serving {len(self.users)} users in {len(self.guilds)} servers"
        )
        await self.change_presence(status=discord.Status.online, activity=activity)
        print(f"\n\033[92m✓ Bot Online: {self.user}\033[0m")
        print(f"\033[94m[{discord.utils.utcnow().strftime('%H:%M:%S')}]\033[0m Serving \033[97m{len(self.users)} users in {len(self.guilds)} servers\033[0m")

# --- Logging Setup ---
logger.remove()
logger.add(stdout, level="INFO", colorize=True, enqueue=True, backtrace=True, 
           format="<cyan>[</cyan><blue>{time:YYYY-MM-DD HH:MM:SS}</blue><cyan>]</cyan> (<magenta>Antinuke:{function}</magenta>) <yellow>@</yellow> <fg #BBAAEE>{message}</fg #BBAAEE>")

bot = Antinuke()

if __name__ == "__main__":
    try:
        bot.run(config.TOKEN)
    except Exception as e:
        logger.critical(f"Startup error: {e}")