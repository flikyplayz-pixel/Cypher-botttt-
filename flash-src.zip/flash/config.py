
from dotenv import load_dotenv
load_dotenv(verbose = True)
import os

PREFIX = ","
TOKEN = "MTQ2MzUzMzg5OTg3ODc2MDQ5OA.GobyTu.4jH2xyEE1LHx63Aq3OADs_fDTqIuWJZ239LOmY"
CHANNEL = 1458849059308830762
uri = "database.db"
owners = [1463384068702998710]