# Antinuke Discord Bot

## Overview

This is a Discord bot called "Antinuke" built with discord.py. The bot provides moderation, utility, and anti-abuse features for Discord servers. It includes functionality for blacklisting users/guilds, clearing messages, user information lookup, profile management, and AFK status tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Framework**: discord.py with command extension
- **Bot Class**: Custom `Antinuke` class extending `Bot` with additional properties (color theme, config, browser session, database)
- **Command Prefix**: Dynamic prefix via `get_prefix` method
- **Cog Structure**: Modular cog-based architecture for organizing commands by category

### Cog Organization
Commands are organized into separate cog modules:
- `developer.py` - Owner-only commands (blacklist management)
- `information.py` - User information commands (avatar, banner, help)
- `listeners.py` - Event listeners (AFK system)
- `moderation.py` - Moderation tools (message purging, reaction muting)
- `profile.py` - User profile system with social links
- `utility.py` - General utility commands (userinfo)

### Database Layer
- **Database**: SQLite via aiosqlite
- **Wrapper**: Custom `Database` class in `backend/database.py`
- **Record Type**: Custom `Record` class extending dict for attribute-style access
- **Connection Pattern**: Per-query connections with row factory for dict conversion

### Browser Automation
- **Library**: Playwright with async API
- **Purpose**: Web scraping/automation capabilities
- **Stealth**: Uses playwright-stealth for anti-detection
- **Session Management**: Pool-based page management with busy tracking

### Configuration
- **Method**: Environment variables via python-dotenv
- **Config File**: `config.py` stores TOKEN, PREFIX, and database URI
- **Database Path**: `database.db` (SQLite file)

### Context Extensions
Custom methods added to discord.py Context:
- `ctx.success(message)` - Send success embed
- `ctx.fail(message)` - Send error embed

### Logging
- **Library**: Loguru
- **Format**: Timestamped with function name and colored output
- **Output**: stdout

## External Dependencies

### Python Packages
- `discord.py` - Discord API wrapper
- `aiosqlite` - Async SQLite database access
- `loguru` - Logging
- `ujson` - Fast JSON parsing
- `python-dotenv` - Environment variable loading
- `playwright` - Browser automation (implied by browser.py)
- `playwright-stealth` - Anti-detection for Playwright
- `tuuid` - UUID generation for page tracking

### Environment Variables Required
- `TOKEN` - Discord bot token

### Discord API Features Used
- Custom activities
- Intents system
- Embed messages
- View components (buttons, selects)
- Permission checks
- Guild and user caching

### Jishaku Integration
The bot configures Jishaku (discord.py debugging cog) with environment variables for customized behavior:
- No underscore prefix
- No DM tracebacks
- Hidden from help
- Forced pagination
- Session retention